<?php
    session_start();
    
    // Check if user is logged in as an admin
    if (!isset($_SESSION["AdminID"]) || $_SESSION["admin_login"] !== true) {
        header("Location: admin_login.php");
        exit();
    }
?>
<title>Customers Information</title>
<script src="js/openForm.js"></script>
<link rel="stylesheet" href="new_css/style.css">
<div class="add-button-container">
  <button class="add-button" onclick="openAddForm()">Add</button>
</div>
<table class="admintable">
  <thead>
    <tr>
      <th>Product ID</th>
      <th>Category ID</th>
      <th>Product Name</th>
      <th>Price</th>
      <th>Size</th>
      <th>Stock</th>
      <th>Product Image Path</th>
      <th>Product Description</th>
      <th>Rating</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php
      // Create database connection.
      $config = parse_ini_file('../../private/db-config.ini');
      $conn = new mysqli($config['servername'], $config['username'],
      $config['password'], $config['dbname']);

      // Check connection
      if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }

      // Retrieve data from database
      $stmt = $conn->prepare("SELECT * FROM UniQthes.Product;");
      $stmt->execute();
      $result = $stmt->get_result();
      
      // Initialize a counter variable
      $counter = 0;
      
      if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
          $counter++;  
          echo "<tr>";
          echo "<td>" . $row["ProductID"] . "</td>";
          echo "<td>" . $row["CategoryID"] . "</td>";
          echo "<td>" . $row["productName"] . "</td>";
          echo "<td>" . $row["price"] . "</td>";
          echo "<td>" . $row["size"] . "</td>";
          echo "<td>" . $row["stock"] . "</td>";
          echo "<td>" . $row["productImgPath"] . "</td>";
          echo "<td>" . $row["productDesc"] . "</td>";
          echo "<td>" . $row["rating"] . "</td>";
          echo "<td><a href='#' id='edit-link-" . uniqid() . "' onclick='openEditForm(" . $row["ProductID"] . ", \"" . $row["size"] . "\")'>Edit</a> | <a href='admin_product_delete.php?id=" . $row["ProductID"] . "&size=" . $row["size"] . "' onclick='return confirm(\"Are you sure you want to delete this product?\")'>Delete</a></td>";
          echo "</tr>";

        }
      } else {
        echo "0 results";
      }

      $conn->close();
    ?>
  </tbody>
</table>


