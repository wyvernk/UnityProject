<?php
  session_start();

  // Check if user is logged in as an admin
  if (!isset($_SESSION["AdminID"]) || $_SESSION["admin_login"] !== true) {
    header("Location: admin_login.php");
    exit();
  }

  if(isset($_POST['resolved_button'])) {
      ResolveEnquiry();
}

function ResolveEnquiry()
{
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);

    $stmt = $conn->prepare("DELETE FROM Enquiries WHERE EnquiriesID=?");
    $stmt->bind_param("i", $_POST['resolved_button']);
    $stmt->execute();
    $stmt->close();
    $conn->close();
}

function PrintEnquiries()
{
    session_start();
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);

    $stmt = $conn->prepare("SELECT * FROM Enquiries");
    $stmt->execute();
    $result = $stmt->get_result();

    while($row = $result->fetch_assoc())
    {
        echo '<div class="card_item">';
        echo "<h2>Enquirer: ". $row["enquirerName"] ."</h2>";
        echo "<h3>Enquirer Email: ". $row["enquirerEmail"] ."</h3>";
        echo "<h3>Enquiry Date: ". $row["enquiryDate"] ."</h3>";
        echo "<br>";
        echo "<h3>Enquiry: </h3>";

        echo "<p>" . $row["enquiry"] . "</p>";

        echo '<div class="center_text">';
        echo "<form method='post'>";       
        echo "<input type='hidden' name='resolved_button' class='site-btn' value={$row["EnquiriesID"]}>";
        echo "<button type='submit' class='site-btn'>Resolved</button>";
         echo "<a href='mailto:{$row["enquirerEmail"]}' target='_blank' class='site-btn'>Reply</a>";
        echo "</form>"; 
        echo '</div>';
        echo "</div>";

        echo "<hr>";
    }

    $stmt->close();
    $conn->close();
}
?>


<link rel="stylesheet" href="new_css/style.css">
<section class="section">
    <div class="container">
        <div class="section-title">
            <h1>Enquiries</h1>
        </div>
        <?php
        PrintEnquiries();
        ?>
    </div>
</section>
