<!DOCTYPE html>
<?php
    session_start();
    if(!empty($_SESSION['lname']))
    {
        if(!empty($_SESSION['fname']))
        {
            $name = $_SESSION['fname'] . ' ' ;
        }
        $name .= $_SESSION['lname'];
    }
    else
    {
        $name = "";
    }
    $email = $_SESSION["email"];
?>

<html lang="en">
<?php 
    include "new_includes/head.inc.php"
?>
        
    <!-- start of about -->
<body>
        <!-- Custom JS -->
        <script defer src="js/validation.js"></script>
        
<main>
    <?php 
        include "new_includes/nav.inc.php"
    ?>
    <!-- About Section Begin -->
    <section class="section">
        <div class="container">
             <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Who Are We?</h2>
                        <p>We are a small group of fashion designers who wish to deliver the highest quality of clothing products.</p>
                    </div>
             </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="about__pic">
                        <img src="img/about/about-us.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title">
                        <h2>Our Mantra</h2>
                         <p>"Don't ask an A+ from your superiors, ask an A+ from ourselves"<p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About Section End -->

   <!-- Map Section Begin -->
   <div class="row">
        <div class="col-lg-12">
            <div class="section-title">
             <h2>Where Are We?</h2>
            </div>
        </div>
   </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="map">
       <iframe title="map" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.66540302967!2d103.84659831470137!3d1.3774333989953997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31da16e96db0a1ab%3A0x3d0be54fbbd6e1cd!2sSingapore%20Institute%20of%20Technology%20(SIT%40NYP)!5e0!3m2!1sen!2ssg!4v1678334178074!5m2!1sen!2ssg" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
    </div>
    <!-- Map Section End -->

    <!-- Contact Section Begin -->
    <section class="section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="contact__text">
                        <div class="section-title">
                            <h2>Contact Us</h2>
                            <p>If you have any enquiries, please feel free to contact us through our hotline or email. Alternatively, you may send us a message through our form and we will reply you as soon as possible through the entered email address.</p>
                        </div>
                        <ul>
                            <li>
                                <h3>Hotline</h3>
                                <p>+65 1234 5678 <br />Mondays - Fridays, 8am - 9pm</p>
                            </li>
                            <li>
                                <h3>Email</h3>
                                <p>uniqthesbusiness@gmail.com</p>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="contact__form">
                        <form action="process_about.php" method="post">
                            <div class="row">
                                <div class="col-lg-6">
                                     <div class="contact__form">
                                         <p>Name<span>*</span></p>
                                        <input class="form-control" type="text" id="name" name="name" maxlength="45"  placeholder="Name" value="<?php echo isset($name) ? $name :' ';?>" data-validation-required-message="Please enter your name" required>
                                        <div class="invalid-feedback"></div>
                                     </div>
                                </div>
                                <div class="col-lg-6">
                                     <div class="contact__form">
                                         <p>Email<span>*</span></p>
                                        <input class="form-control" type="email" id="email" name="email" maxlength="45" placeholder="Email" value="<?php echo isset($email) ? $email :' ';?>" data-validation-required-message="Please enter a valid email" required>
                                        <div class="invalid-feedback"></div>
                                     </div>
                                </div>
                                <div class="col-lg-12">
                                     <div class="contact__form">
                                        <p>Message<span>*</span></p>
                                        <textarea class="form-control" placeholder="Message" name="message" data-validation-required-message="Please enter your message" maxlength="500" required></textarea>
                                        <div class="invalid-feedback"></div>
                                     </div>
                                    <button type="submit" class="site-btn">Send Message</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    </main>
    <!-- Contact Section End -->
    <?php 
        include "new_includes/footer.inc.php";
    ?>
</body>
</html>
