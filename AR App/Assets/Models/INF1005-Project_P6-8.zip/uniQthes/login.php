<!DOCTYPE html>
<html lang="en">

    <?php include "client.php"; ?>

    <?php 
        session_start();
        $loginErr = $_SESSION["loginErr"];
        $email = $_SESSION["email"];

        if(isset($_SESSION["login"]))
        header("location:profile.php");
        
        include "new_includes/head.inc.php";
    ?>

    <body>
        <script defer src="js/validation.js"></script>

        <main>
            <?php 
                include "new_includes/nav.inc.php";
            ?>

            <section>
                <div class="container py-5 h-100">
                    <div class="row d-flex justify-content-center align-items-center h-100">
                        <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                            <div class="card shadow-2-strong" style="border-radius: 1rem;">
                                <div class="card-body p-5 text-center" style="background-color:#fdfdfd;">

                                    <h2 class="mb-5">Login</h2>

                                    <form method="post" action="process_login.php">
                                        <span class="errMsg"><?php echo $loginErr ?></span><br>

                                        <div class="form-outline mb-2">
                                            <label class="form-label" for="email"></label>
                                            <input class="form-control form-control-mg" type="email" id="email" required name="email" value="<?php echo $email ?>" maxlength="45" data-validation-required-message="Please enter your email" placeholder="Email" required>
                                            <div class="invalid-feedback"></div>
                                        </div>

                                        <div class="form-outline mb-2">
                                            <label class="form-label" for="pwd"></label>
                                            <input class="form-control form-control-mg" type="password" id="pwd" required name="pwd" data-validation-required-message="Please enter your password" maxlength="45" placeholder="Password" >
                                            <div class="invalid-feedback"></div>
                                        </div>

                                        <button class="site-btn btn-lg submit-btn" type="submit">Login</button>
                                    </form>
                                    <hr class="my-2">

                                    <div>
                                        <button class="site-btn btn-lg google-btn" type="button"
                                            onclick="window.location='<?php echo $client->createAuthUrl(); ?>'">
                                            <i class="fab fa-google me-2"></i> Sign in with Google
                                        </button>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div class="container signin">
                <p>Don't have an account? <a href="register.php">Register here</a>.</p>
            </div>
        </main>

        <?php 
            if(!isset($_SESSION["login"])) {
                unset(
                    $_SESSION["loginErr"],
                    $_SESSION["email"]
                );
            } 
        ?>

        <?php include "new_includes/footer.inc.php"; ?>
    </body>
</html>