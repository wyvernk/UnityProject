<!DOCTYPE html>
<?php

    session_start ();
	if(!isset($_SESSION["login"])) {
		header("location:index.php");
		exit();
	}

if(isset($_POST['cancel_button'])) {
       CancelOrder();
}

function CancelOrder()
{
    $orderid = $_POST['cancel_button'];
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);
   
    
    $stmt = $conn->prepare("UPDATE Orders SET orderStatus ='Cancelled' WHERE OrderID =?");
    $stmt->bind_param("i", $orderid);
    $stmt->execute();
    
    $conn->close();
}

function PrintOrderHistory()
{
    session_start();
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);
    
    $stmt = $conn->prepare("SELECT * FROM Orders WHERE Orders.CustomerID = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    
    while($row = $result->fetch_assoc())
    {      
        $orderstatus = $row["orderStatus"];
        echo     '<div class="card_item">';
        echo     '<div class="row">';
            echo     '<div class="col-lg-12">';
            echo     "<h2>Order ID: #". $row["OrderID"] . "</h2>";
            echo     "</div>";
        echo     "</div>";
        echo     '<div class="row">';
            echo     '<div class="col-lg-4">';       
            echo     "<h3>Details: </h3>";
             echo    "<p>Email: ". $row["customerEmail"] ."</p>";
            echo     "<p>Phone Number: ". $row["customerPhone"] ."</p>";
            echo     "<p>Address: ". $row["deliveryAddress"] ."</p>";
            echo     "<p>Order Date: ". $row["orderDate"] ."</p>";
        echo     "</div>";
        
        echo     '<div class="col-lg-4">';
            echo     "<h3>Order: <span>Price:</span></h3>"; 
            

        $stmt = $conn->prepare("SELECT * FROM OrderList WHERE OrderList.OrderID = ?");
        $stmt->bind_param("i", $row["OrderID"]);
        $stmt->execute();
        $orderresult = $stmt->get_result();
        
            $pricetotal = 0;
            while($row2 = $orderresult->fetch_assoc())
            {
                echo "<p>" . $row2["productName"] . "(". $row2["size"] . ") x" . $row2["quantity"] . "<span>$" . $row2["price"] . "</span></p>";  
                $pricetotal += $row2["price"] * $row2["quantity"];
            }
              echo "<br>";
              $pricetotal = number_format((float)$pricetotal, 2, '.', '');
            echo     "<p>Total: <span>$" .$pricetotal . "</span></p>";         
        echo "</div>";
            
            echo     '<div class="col-lg-4">';            
                echo     "<h3>Status: " . $orderstatus . "</h3>";                     
            echo     "</div>";
        echo "</div>";
        
        echo  '<div class="row">';
            echo   '<div class="col-lg-12">';
            echo   '<div class="center_text">';
            echo   "<p>Notes: ". $row["orderNotes"] ."</p>";
            if ($orderstatus == 'Pending')
            {
                echo   "<form method='post'>";
                echo   "<input type='hidden' name='cancel_button' class='site-btn' value={$row["OrderID"]}>";              
                echo   "<button type='submit' class='site-btn'>Cancel Order</button>";
                echo   "</form>";
            }
             
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";     
         
        echo "<hr>";
    }
    $stmt->close();
    $conn->close();
}
?>

<html lang="en">


    
<?php 
    include "new_includes/head.inc.php"
?>
    
<body>
    <main>
        <?php 
            include "new_includes/nav.inc.php"
        ?>
        
        <!-- Contact Section Begin -->
        <section class="section">
            <div class="container">
                <div class="row">                
                            <div class="section-title">
                                <h2>Order History</h2>
                            </div>                                         
                                <?php
                                    PrintOrderHistory();
                                ?>
                </div>
            </div>
        </section>
        <!-- Contact Section End -->
        <?php 
            include "new_includes/footer.inc.php";
        ?>
    </main>
</body>
