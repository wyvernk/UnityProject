<footer class="container-fluid text-center">
  <p>Copyright © 2023 Uniqlothes Pte. Ltd. </p>  
</footer>