<?php
if (!isset($_SESSION)) {
    session_start();
}
?>

<div class="jumbotron jumbotron-fluid">
  <div class="container text-center">
    <h1>Uniqlothes</h1>      
        <p>We strive for our A+</p>
  </div>
</div>

<nav class="navbar navbar-dark navbar-expand-lg bg-body-tertiary" data-bs-theme="dark">
    <div class="container-fluid">
            <a class="navbar-brand" href="index.php">Uniqlothes</a>
             <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page"  href="products.php">Shop</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="about.php">About Us</a>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">

                <!-- If not logged in -->
                <?php if (!isset($_SESSION["login"])) { ?>

                    <li class="nav-item"><a class="nav-link" href="login.php"><span class="fa-solid fa-user"></span>Login / Register</a></li>

                <?php } else { ?>

                    <li class="nav-item"><a class="nav-link" href="profile.php"><span class="fa-solid fa-user"></span>  <?php echo $_SESSION["fname"] . " " .  $_SESSION["lname"] ?></a></li>
                    <li class="nav-item"><a class="nav-link" href="orderhistory.php"><span class="fa-solid fa-user"></span>  Orders</a></li>

                    <li class="nav-item"><a class="nav-link" href="logout.php"><span class="fa-solid fa-user"></span>  Log Out</a></li>

                <?php } ?>


                <li class="nav-item"><a class="nav-link" href="shopping-cart.php"><span><?php echo count($_SESSION["cart"]); ?></span><span class="fa-solid fa-cart-shopping"></span> Cart</a></li>
            </ul>
        </div>
    </div>
</nav>