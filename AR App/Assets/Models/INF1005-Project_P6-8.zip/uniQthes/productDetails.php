<!DOCTYPE html>
<html lang="en">

    <?php include "new_includes/head.inc.php"; ?>

    <?php
    session_start();
    if (isset($_GET["myid"])) {
        include "fetchProductDetails.php";
    } else {
        header("Location:index.php");
    }

    function ShowReviews() {
        global $ProductID;
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
                $config['password'], $config['dbname']);

        $stmt = $conn->prepare("SELECT * FROM Reviews INNER JOIN User ON Reviews.UserID = User.UserID where ProductID = {$ProductID}");
        $stmt->execute();
        $result = $stmt->get_result();

        // Check connection
        if ($conn->connect_error) {
            $errorMsg = "Connection failed: " . $conn->connect_error;
        } else {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="product-reviews">';
                echo '<div class="card_item">';
                echo "<h3>Review By: " . $row["fName"] . ' ' . $row["lName"] . "</h3>";
                echo "<h4>Date: " . $row["reviewDate"] . "</h4>";
                echo " <div class='original review' id='original_review_" . $row["ReviewID"] . "'>";
                echo " <div class='star-rating'>";
                for ($x = 0; $x < 5; $x++) {
                    if ($x <= $row["reviewRating"] - 1) {
                        echo " <i class='fa fa-star' style='color: yellow'></i>";
                    } else {
                        echo " <i class='fa fa-star'></i>";
                    }
                }
                echo "</div>";
                echo "<br>";
                echo "<p>" . $row["reviewText"] . "</p>";
                echo "</div>";
                if ($row["UserID"] == $_SESSION["user_id"]) {

                    echo '<div class="center_text">';
                    echo '<button onclick="EditReview(this, \'' . $row["reviewText"] . '\', ' . $ProductID . ', ' . $row["ReviewID"] . ', ' . $row["reviewRating"] . ')" class="site-btn" name="edit_review_button">Edit Review</button>';

                    echo "<form action='process_review.php' method='post'>";
                    echo "<input type='hidden' name='delete_review_id' class='site-btn' value={$row["ReviewID"]}>";
                    echo "<input type='hidden' name='delete_product_id' class='site-btn' value={$ProductID}>";
                    echo "<button type='submit' name='delete_review_button' class='site-btn'>Delete Review</button>";
                    echo "</form>";
                    echo "</div>";
                }
                echo "</div>";
                echo "</div>";
                echo "<hr>";
            }
        }
        $stmt->close();

        $conn->close();
    }
    ?>

    <?php
    if (isset($_SESSION["message"])) {
        echo '<script type="text/javascript">';
        echo 'jQuery(function($){alert("' . $_SESSION["message"] . '");});';
        echo '</script>';
        unset($_SESSION["message"]);
    }
    ?>
    <body>
        <script defer src="js/editReview.js"></script>

        <main>

            <?php include "new_includes/nav.inc.php" ?>

            <section>
                <div class="productDetails-container">
                    <div class="productDetails-image">
                        <img src="<?php echo $productImgPath ?>" alt="<?php echo $productName ?>">
                    </div>
                    <div class="product-details">
                        <h2 class="product-title"><?php echo $productName ?></h2>
                        <p class="product-price"><?php echo $price ?></p>
                        <p><?php
                            // Display the star rating
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= $Rating) {
                                    echo '<i class="fa-solid fa-star" style="color:yellow;"></i>';
                                } else {
                                    echo '<i class="fa-regular fa-star"></i>';
                                }
                            }
                            echo '</p>'
                            ?>
                        <p class="product-description"><?php echo $productDesc ?></p>
                        <div class="size-selection">
                            <label for="size-select">Size:</label>
                            <div class="dropdown">
                                <select class="form-select" id="size-select" name="size" aria-label="size selection" onchange="setSize(this.value)">
                                    <option value="S" selected>S</option>
                                    <option value="M">M</option>
                                    <option value="L">L</option>
                                </select>
                            </div>
                        </div>
                        <div class="stock">
                            <label id="stock-display">Stock:</label>
                            <div class="stock-count">
                                <p id="stock-S"><?php echo $stock_S ?></p>
                                <p id="stock-M"><?php echo $stock_M ?></p>
                                <p id="stock-L"><?php echo $stock_L ?></p>
                            </div>
                        </div>
                        <!-- Add to cart -->
                        <form method="get" action="add_to_cart.php">
                            <!-- Product details -->
                            <input type="hidden" name="product_id" value="<?php echo $ProductID ?>">
                            <input type="hidden" name="product_img" value="<?php echo $productImgPath ?>">
                            <input type="hidden" name="product_name" value="<?php echo $productName ?>">
                            <input type="hidden" name="product_price" value="<?php echo $price ?>">
                            <input type="hidden" name="product_desc" value="<?php echo $productDesc ?>">
                            <input type="hidden" name="product_size" id="product-size" value="S">

                            <!-- Quantity -->
                            <label for="quantity">Quantity:</label>
                            <div class="dropdown">
                                <select class="form-select quantity" id="quantity" name="quantity" aria-label="quantity selection">
                                    <?php
                                      $startValue = $stock_S == 0 ? 0 : 1;
                                      $maxValue = $stock_S > 6 ? 6 : $stock_S;
                                      for ($i = $startValue; $i <= $maxValue; $i++) {
                                          echo "<option value='$i'" . ($i == $startValue ? " selected" : "") . ">$i</option>";
                                      }
                                  ?>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-primary" id="add-cart-btn">Add to cart</button>
                        </form>
                    </div>

                    <?php
                    if (isset($_SESSION["user_id"])) {
                        echo "<div class='product-reviews'>
                           <h3>Leave a review</h3>           
                           
                            <div class='star-rating'>
                            <i class='fa fa-star editable'></i>
                            <i class='fa fa-star editable'></i>
                            <i class='fa fa-star editable'></i>
                            <i class='fa fa-star editable'></i>
                            <i class='fa fa-star editable'></i>
                          
                            </div>
                        <form action='process_review.php' method='post'>
                        <div class='center_text'>
                            <input type='hidden' name='add_review_product_id' class='site-btn' value={$ProductID}>
                            <input id='rating' name='rating' class='form-control' value='' placeholder='rating' required>
                          <textarea class='form-control' placeholder='Review' name='Review' maxlength='500' required></textarea>                
                            <button type='submit' class='site-btn'>Post Review</button>
                        </form>
                     </div>
                      </div>
                     <hr>";
                    } else {
                        echo "<div class='product-details'>
                           <p><a href='login.php'>Login </a>to leave a review.</p>
                           </div>
                           <hr>";
                    }

                    ShowReviews();
                    ?>
                </div>
            </section>
            <script src="js/autoUpdate.js"></script>

        </main>
        <?php
        include "new_includes/footer.inc.php"
        ?>

    </body>

</html>