<?php 
	session_start ();
	if(isset($_SESSION["login"])) {
        header("location:index.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
<?php 
    include "new_includes/head.inc.php"
?>

<body>
    <script defer src="js/validation.js"></script>
    
    <main>
        <?php 
            include "new_includes/nav.inc.php"
        ?>

        <?php 
            // Initialise global error messages
            $fname = $lname = $email = $address= $phonenumber ="";
            $formErr = $fnameErr = $lnameErr = $emailErr = $phonenumberErr = $pwdErr = $pwdConfirmErr = $dbErr = "";
            $success = true;

            // Form errors
            $formErr = $_SESSION["formErr"];
            $fnameErr = $_SESSION["fnameErr"];
            $lnameErr = $_SESSION["lnameErr"];
            $emailErr = $_SESSION["emailErr"];
            $pwdErr = $_SESSION["pwdErr"];
            $phonenumberErr =  $_SESSION["phonenumberErr"];
            $pwdConfirmErr = $_SESSION["pwdConfirmErr"];

            // Form values
            $fname = $_SESSION["fname"];
            $lname = $_SESSION["lname"];
            $email = $_SESSION["email"];
            $address = $_SESSION["address"];
            $phonenumber = $_SESSION["phonenumber"];

        ?>

        <section>
            <div class="container">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-12 col-md-8 col-lg-6 col-xl-6">
                        <div class="card shadow-2-strong" style="border-radius: 1rem;">
                            <div class="card-body p-5 text-center" style="background-color:#fdfdfd;">
                                <h2 class="mb-5">Registration</h2>

                                <form method="post" action="process_register.php">
                                    <p>Please fill in this form to create an account.</p>
                                    
                                    <br>
                                    <span class="errMsg"><?php echo $formErr; ?></span><br>

                                    <!-- Email -->
                                    <br><label for="email">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>" maxlength="45" data-validation-required-message="Please enter your email" placeholder="Email" required>
                                    <div class="invalid-feedback"></div>
                                    <span class="errMsg"><?php echo $emailErr; ?></span><br>
                                    

                                    <!-- First Name -->
                                    <div class="form-outline mb-1">
                                        <br><label for="fname">First name</label>
                                        <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $fname; ?>"  maxlength="45" placeholder="First name">
                                        <span class="errMsg"><?php echo $fnameErr; ?></span>
                                    </div>

                                    <!-- Last Name -->
                                    <div class="form-outline">
                                        <br><label for="lname">Last name</label>
                                        <input type="text" class="form-control" id="lname" name="lname" value="<?php echo $lname; ?>" maxlength="45" placeholder="Last name" data-validation-required-message="Please enter your last name" required>
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $lnameErr; ?></span><br>
                                    </div>

                                    <!-- Address -->
                                    <div class="form-outline">
                                        <br><label for="address">Address</label>
                                        <input type="text" class="form-control" id="address" name="address" value="<?php echo $address; ?>" maxlength="255" placeholder="Address">
                                    </div>

                                    <!-- Phone number -->
                                    <div class="form-outline">
                                        <br><label for="phonenumber">Phone</label>
                                        <input type="tel" pattern="[0-9]{8}" class="form-control" id="phonenumber" name="phonenumber" maxlength="8" minlength="8"  value="<?php echo $phonenumber; ?>" data-validation-required-message="Please enter a valid phone number" placeholder="Phone number">
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $phonenumberErr; ?></span><br>
                                    </div>

                                    <!-- Password -->
                                    <div class="form-outline">
                                        <br><label for="pwd">Password</label>
                                        <input type="password" class="form-control" id="pwd" name="pwd" placeholder="Password" data-validation-required-message="Please enter a password" maxlength="45" required>
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $pwdErr; ?></span><br> 
                                    </div>
                                    
                                    <!-- Comfirm Password -->
                                    <div class="form-outline">
                                        <br><label for="pwd_confirm">Confirm password</label>
                                        <input type="password" class="form-control" id="pwd_confirm" name="pwd_confirm" placeholder="Confirm Password" data-validation-required-message="Please confirm your password" maxlength="45" required>
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $pwdConfirmErr; ?></span><br> 
                                    </div>
                                    
                                    <hr>

                                    <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
                                    <button type="submit" class="site-btn btn-lg submit-btn">Register</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php 
            unset(
                $_SESSION["formErr"],
                $_SESSION["fnameErr"],
                $_SESSION["lnameErr"],
                $_SESSION["emailErr"],
                $_SESSION["pwdErr"],
                $_SESSION["phonenumberErr"],
                $_SESSION["pwdConfirmErr"],
                $_SESSION["fname"],
                $_SESSION["lname"],
                $_SESSION["email"],
                $_SESSION["address"],
                $_SESSION["phonenumber"]
                );
        ?>

        <?php 
            include "new_includes/footer.inc.php";
        ?>
    </main>
</body>

</html>