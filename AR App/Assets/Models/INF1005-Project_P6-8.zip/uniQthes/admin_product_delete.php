<?php
     session_start();
    
    // Check if user is logged in as an admin
    if (!isset($_SESSION["AdminID"]) || $_SESSION["admin_login"] !== true) {
        header("Location: admin_login.php");
        exit();
    }

  // Create database connection.
  $config = parse_ini_file('../../private/db-config.ini');
  $conn = new mysqli($config['servername'], $config['username'],
  $config['password'], $config['dbname']);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Get the Product ID and size from the URL parameters
$id = $_GET['id'];
$size = $_GET['size'];

  // Prepare the SQL statement
  $sql = "DELETE FROM Product WHERE ProductID = ? AND size = ?";
  $stmt = $conn->prepare($sql);
  
  // Bind the variables to the prepared statement as parameters
  $stmt->bind_param("is", $id, $size);
  
  // Execute the statement
  if ($stmt->execute()) {
    // Redirect back to adminpage.php
    header("Location: adminpage.php?page=admin_product_table");
    exit();
  } else {
    echo "Error deleting record: " . $conn->error;
  }
  
  $stmt->close();
  $conn->close();
  
?>
