<?php 
	session_start ();
	if(!isset($_SESSION["login"])) {
		header("location:login.php");
		exit();
	}

		$editAccErr = $_SESSION["editAccErr"];
		
?>

<!DOCTYPE html>
<html lang="en">

<?php 
    include "new_includes/head.inc.php"
?>

<body>
	<main>
		<?php 
			include "new_includes/nav.inc.php"
		?>

		<div class="container">

			<div class="card_item">
				<span class="errMsg"><?php echo $editAccErr ?></span><br>
				<h2>
					MY ACCOUNT
					<a href="edit_account.php" title="Edit">		
						<i class="fa fa-edit" style="font-size:24px"></i>		
					</a>
				</h2>

				<br>

				<div class="row">
					<div class="col-sm-3">
						<h3>EMAIL ADDRESS</h3>
						<p><?php echo $_SESSION["email"]; ?></p>
					</div>
					
					<div class="col-sm-3">
						<h3>CONTACT NUMBER</h3>
						<p><?php echo $_SESSION["phonenumber"]; ?></p>
					</div>
				</div>

				<br>

				<div class="row">
					<div class="col-sm-3">
						<h3>NAME</h3>
						<p><?php echo $_SESSION["fname"] . " " . $_SESSION["lname"]; ?></p>
					</div>
					
					<div class="col-sm-3">
						<h3>ADDRESS</h3>
						<p><?php echo $_SESSION["address"]; ?></p>
					</div>
				</div>
			</div>	

			<?php
				if(!isset($_SESSION["google"])) {
					echo 
					"<button onclick=\"window.location.href='change_password.php'\" class=\"site-btn\">Change Password</button>";
				}
			?>	
			
		</div>
	</main>
	
	<?php 
		include "new_includes/footer.inc.php";
	?>
</body>