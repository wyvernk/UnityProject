<!DOCTYPE html>
<html lang="en">
    <?php include "new_includes/head.inc.php" ?>

    <body>
        <main>
        <?php include "new_includes/nav.inc.php" ?>
        <?php   
            include "fetchProduct.php"
        ?>

        <section class="product-section">
            <div class="container-fluid"> 
                <div class="row">
                    <div class="col-md-3">
                        <div class="product__sidebar">                    
                            <div class="product__sidebar__accordion">
                                <div class="accordion accordion-flush" id="accordionFlushExample">
                                    <div class="product__sidebar__search">
                                        <form class="form-inline" method="post" action="products.php">
                                            <input class="form-control mr-sm-2" type="search" aria-label="Search" name="search">
                                            <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                                        </form>
                                    </div>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="flush-headingOne">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                                Categories
                                            </button>
                                        </h2>
                                        <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                                            <div class="accordion-body">
                                                <div class="card-body">
                                                    <div class="product__sidebar__categories">
                                                        <ul class="list-group list-group-flush">
                                                            <li><a href="?categoryID=1">Top</a></li>
                                                            <li><a href="?categoryID=2">Bottom</a></li>
                                                        </ul>
                                                    </div>
                                                </div> </div>
                                        </div>
                                    </div>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="flush-headingTwo">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                                                Filter Price
                                            </button>
                                        </h2>
                                        <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                                            <div class="accordion-body">
                                                <div class="card-body">
                                                    <div class="product__sidebar__price">
                                                        <ul class="list-group list-group-flush">
                                                            <li><a href="?priceRange=0-50">$0.00 - $50.00</a></li>
                                                            <li><a href="?priceRange=50-100">$50.00 - $100.00</a></li>
                                                            <li><a href="?priceRange=100-150">$100.00 - $150.00</a></li>
                                                            <li><a href="?priceRange=150-200">$150.00 - $200.00</a></li>
                                                            <li><a href="?priceRange=250-300">$200.00 - $250.00</a></li>
                                                            <li><a href="?priceRange=300-9999">250.00+</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="reset-search">
                                            <form class="form-inline" method="post" action="products.php">
                                                <input class="form-control mr-sm-2" type="hidden" name="search">
                                                <button class="btn btn-primary" type="submit">Reset</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="product-display">
                            <?php
                            $numOfProductsPerPage = 9;

                            // Get the current page number
                            $currentPage = isset($_GET['page']) ? (int) $_GET['page'] : 1;

                            // Calculate the offset
                            $offset = ($currentPage - 1) * $numOfProductsPerPage;

                            // Get the total number of products
                            $totalProducts = count($products);

                            // Calculate the total number of pages
                            $totalPages = ceil($totalProducts / $numOfProductsPerPage);

                            // Get the products for the current page
                            $productsForPage = array_slice($products, $offset, $numOfProductsPerPage);

                            $numOfProductsOnPage = count($productsForPage);
                            ?>
                            <div class="row">
                                <?php
                                echo '<div class="shop__product__option__left">
          <h3>Showing 1–' . $numOfProductsOnPage . ' of ' . $totalProducts . '  results</h3>
      </div>';
                                ?>
                            </div>
                            <div class="row" id="products">
                                <?php
                                // Set the number of products to display per page
                                $maxStar =5 ;
                                if ($success == true) {
                                    foreach ($productsForPage as $item) {
                                        echo '  
                                    <div class="col-sm-4">
                                        <div class="card">
                                            <a href="productDetails.php?myid=' . $item["ProductID"] . '" aria-label="Read more about the product">
                                                <img class="card-img-top" src="' . $item["productImgPath"] . '" alt="more about ' . $item["productName"] . '">
                                            </a>      
                                        <div class="card-body">
                                             <h2 class="title">' . $item["productName"] . '</h2>
                                                 <div class="rating">'; 
// Display the star rating
              for ($i = 1; $i <= $maxStar; $i++) {
                if ($i <= $item["rating"]) {
                  echo '<i class="fa-solid fa-star" style="color:yellow;"></i>';
                } else {
                  echo '<i class="fa-regular fa-star"></i>';
                }
              }
              echo '
                                                 </div>
                                              <span class="price">$' . $item["price"] . '</span>
                                        </div>
                                           <a href="productDetails.php?myid=' . $item["ProductID"] . '" aria-label="Read more about product">
                                                <span role="group" class="more-info" aria-label="Read more about product"></span>
                                            </a>    
                                      </div>
                                  </div>';
                                    }
                                } else {
                                    echo '<h1>No reuslt</h1>';
                                }
                                ?>
                                <nav aria-label="...">
                                    <ul class="pagination">
                                        <li class="page-item <?php echo ($currentPage <= 1) ? 'disabled' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $currentPage - 1; ?>" tabindex="-1">Previous</a>
                                        </li>
                                        <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
                                            <li class="page-item <?php echo ($currentPage == $i) ? 'active' : ''; ?>"><a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a></li>
                                        <?php } ?>
                                        <li class="page-item <?php echo ($currentPage >= $totalPages) ? 'disabled' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $currentPage + 1; ?>">Next</a>
                                        </li>
                                    </ul>

                                </nav>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </section>
            </main>
    </body>
</html>