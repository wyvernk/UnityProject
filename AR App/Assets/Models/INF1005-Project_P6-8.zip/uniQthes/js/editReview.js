$( document ).ready(function() {
    
AddEventListeners();

});

var EditForm = null;
var CancelButton = null;
var stars = null;
const editstars = [];
var originalreview = null;
var editoriginalrating = 0;
var starsrating = 0;
function AddEventListeners()
{
    stars = document.getElementsByClassName("fa fa-star editable");
    for (let i = 0; i < stars.length; i++) 
    {
        stars[i].addEventListener("click", function(){ StarRating(i + 1); });
        stars[i].addEventListener("mouseover", function(){ HighlightStar(false, i + 1); });
        stars[i].addEventListener("mouseleave", function(){ UnHighlightStar(false); });
    }
}

function HighlightStar(edit, index)
{
    if(edit)
    {
        for (let i = 0; i < editstars.length; i++) 
        {
            editstars[i].style.color = "";
        }

        for (let i = 0; i < index; i++) 
        {
            editstars[i].style.color = "yellow";
        }
    }
    else
    {
         for (let i = 0; i < stars.length; i++) 
        {
            stars[i].style.color = "";
        }

        for (let i = 0; i < index; i++) 
        {
            stars[i].style.color = "yellow";
        }
    }
}


function UnHighlightStar(edit)
{
    if(edit)
    {
        for (let i = 0; i < editstars.length; i++) 
        {
            editstars[i].style.color = "";
        }

        for (let i = 0; i < editoriginalrating; i++) 
        {
            editstars[i].style.color = "yellow";
        }
    }
    else
    {
         for (let i = 0; i < stars.length; i++) 
        {
            stars[i].style.color = "";
        }

        for (let i = 0; i < starsrating; i++) 
        {
            stars[i].style.color = "yellow";
        }
    }
}

function StarRating(index)
{
    for (let i = 0; i < stars.length; i++) 
    {
        stars[i].style.color = "";
    }
    
    for (let i = 0; i < index; i++) 
    {
        stars[i].style.color = "yellow";
    }
    
    var rating = document.getElementById("rating");
    rating.value = index;
    starsrating = index;
}

function EditStarRating(index)
{
    for (let i = 0; i < editstars.length; i++) 
    {
        editstars[i].style.color = "";
    }
    
    for (let i = 0; i < index; i++) 
    {
        editstars[i].style.color = "yellow";
    }
    
    var rating = document.getElementById("edit_rating");
    rating.value = index;
    editoriginalrating = index;
}

function EditReview(element, reviewText, productid, reviewid, rating)
{
    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", "process_review.php");
    
    const textarea = document.createElement("textarea");
    textarea.setAttribute("name", "updated_review_text");
    textarea.setAttribute("class", "form-control");
    textarea.setAttribute("placeholder", "edit review text");
    textarea.value = reviewText;
    textarea.required = true;
        
    var inputfield = document.createElement("input");
    inputfield.setAttribute("type", "hidden");
    inputfield.setAttribute("name", "update_review_product_id");
    inputfield.setAttribute("class", "site");
    inputfield.setAttribute("value", productid);
    
    var inputfield2 = document.createElement("input");
    inputfield2.setAttribute("type", "hidden");
    inputfield2.setAttribute("name", "update_review_id");
    inputfield2.setAttribute("class", "site");
    inputfield2.setAttribute("value", reviewid);

    var updatebtn = document.createElement("button");
    updatebtn.setAttribute("type", "submit");
    updatebtn.setAttribute("class", "site-btn");
    updatebtn.innerHTML = "Update";
     
    var editablestardiv = document.createElement("div");
    editablestardiv.setAttribute("class", "star-rating");
    for (let i = 0; i < 5; i++) {
        var  editablestar = document.createElement("i");
        editablestar.setAttribute("class", "fa fa-star editable2");
        if(i <= rating -1)
        {
             editablestar.style.color ="yellow";
        }
         editstars.push(editablestar);
         editablestar.addEventListener("click", function(){ EditStarRating(i + 1); });
         editablestar.addEventListener("mouseover", function(){ HighlightStar(true, i + 1); });
         editablestar.addEventListener("mouseleave", function(){ UnHighlightStar(true); });
         editablestardiv.appendChild(editablestar);
    }
    
    editoriginalrating = rating;
    
    var editstarsinput = document.createElement("input");
    editstarsinput.setAttribute("id", "edit_rating");
    editstarsinput.setAttribute("name", "edit_rating");
    editstarsinput.setAttribute("class", "form-control");
    editstarsinput.setAttribute("value", rating);
    editstarsinput.setAttribute("placeholder", "edit rating");
    editstarsinput.required = true;
    
    form.appendChild(editablestardiv);
    form.appendChild(editstarsinput);
    form.appendChild(textarea);
    form.appendChild(inputfield);
    form.appendChild(inputfield2);
    form.appendChild(updatebtn);
    
    element.insertAdjacentElement("beforebegin", form);
    
    EditForm = form;
    
    var cancelbtn = document.createElement("button");
    cancelbtn.setAttribute("type", "submit");
    cancelbtn.setAttribute("class", "site-btn");
    cancelbtn.setAttribute("onclick", "CancelEdit()");
    cancelbtn.innerHTML = "Cancel";
    element.insertAdjacentElement("beforebegin", cancelbtn);
    CancelButton = cancelbtn;
    
    originalreview = document.getElementById("original_review_" + reviewid);
    originalreview.style.display = "none";
    
    const deletebuttons = document.getElementsByName("delete_review_button");
    for (let i = 0; i < deletebuttons.length; i++) {
        deletebuttons[i].style.display = "none";
    }
    
     const editbuttons = document.getElementsByName("edit_review_button");
    for (let i = 0; i < editbuttons.length; i++) {
        editbuttons[i].style.display = "none";
    }
}

function CancelEdit()
{
    if(EditForm!=null)
    {
        editstars.length = 0;
        CancelButton.remove();
        EditForm.remove();
    }
    
    const deletebuttons = document.getElementsByName("delete_review_button");
    for (let i = 0; i < deletebuttons.length; i++) {
        deletebuttons[i].style.display = "";
    }
    
     const editbuttons = document.getElementsByName("edit_review_button");
    for (let i = 0; i < editbuttons.length; i++) {
        editbuttons[i].style.display = "";
    }
    originalreview.style.display = "";
}
