$(document).ready()
{
    ValidationMessage();
};

function ValidationMessage() 
{
    // Find form elements with custom data validation messages
    $('form').find('[data-validation-required-message]').each(function () 
    {
        //set custom validation message to form elements
        $(this).attr('data-error', $(this).data('validation-required-message'));
    });

    // Listener to check if user is no longer on form element
    $('form :input').blur(function ()
    {
        var $this = $(this);
        
        //check validity of current element
        if (!$this[0].checkValidity())
        {
            //when invalid, add class is-invalid for css and set invalid feedback to display custom error message
            $this.addClass('is-invalid'); 
            $this.next('.invalid-feedback').text($(this).data('validation-required-message'));
        } 
        else 
        {
             //when valid, remove class is-invalid and remove error message
            $this.removeClass('is-invalid');
            $this.next('.invalid-feedback').text('');
        }
    });
}