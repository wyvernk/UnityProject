function openEditForm(id, size) {
  // Calculate the center of the screen
  var left = (screen.width - 600) / 2;
  var top = (screen.height - 400) / 2;

  // Create a pop-up window
  var popup = window.open("admin_product_edit.php?id=" + id + "&size=" + size, 
  "Edit Product", "width=600,height=400,left=" + left + ",top=" + top);

  // Wait for the pop-up window to close
  var timer = setInterval(function() {
    if (popup.closed) {
      clearInterval(timer);
      location.reload();
    }
  }, 1000);
}


function openAddForm() {
  // Calculate the center of the screen
  var left = (screen.width - 600) / 2;
  var top = (screen.height - 400) / 2;

  // Create a pop-up window
  var popup = window.open("admin_product_add.php", "Add Product", "width=600,\n\
height=400,left=" + left + ",top=" + top);

  // Wait for the pop-up window to close
  var timer = setInterval(function() {
    if (popup.closed) {
      clearInterval(timer);
      location.reload();
    }
  }, 1000);
}
$(function() {
    // When the Select Image button is clicked
    $('#selectImageBtn').click(function() {
      // Open the file selection dialog
      $('<input type="file">').change(function() {
        // Get the path of the selected file
        var filePath = $(this).val();
        // Set the path in the input field
        $('#productImgPath').val(filePath);
      }).click();
    });
  });

function confirmDelete(id) {
    // remove previous event listener if it exists
    document.getElementById('delete-link-' + id).removeEventListener('click', deleteRow);

    // add new event listener with confirmation prompt
    document.getElementById('delete-link-' + id).addEventListener('click', deleteRow);

    function deleteRow(e) {
      e.preventDefault();
      if (confirm("Are you sure you want to delete this customer?")) {
        // Send request to delete.php with User id
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "delete.php", true);
        xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            location.reload();
          }
        };
        xhr.send("id=" + id);
      }
    }
  }
  
function goBack() {
     window.history.back();
    }