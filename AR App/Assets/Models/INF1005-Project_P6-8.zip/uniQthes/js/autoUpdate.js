
$(document).ready()
{
    // Call the setup function on document ready
    getStock();
}
;
function getStock() {
    const sizeSelect = document.getElementById("size-select");
    const stockS = document.getElementById("stock-S");
    const stockM = document.getElementById("stock-M");
    const stockL = document.getElementById("stock-L");
    const addToCartButton = document.getElementById("add-cart-btn");
    sizeSelect.addEventListener('change', () => {
        const selectedValue = sizeSelect.value;
            if (selectedValue === 'S') {
                stockS.style.display = "inline";
                stockM.style.display = "none";
                stockL.style.display = "none";
                 if (stockS.textContent === '0') {
                addToCartButton.disabled = true;
            } else {
                addToCartButton.disabled = false;
            }
            } else if (selectedValue === 'M') {
                stockS.style.display = "none";
                stockM.style.display = "inline";
                stockL.style.display = "none";
                if (stockM.textContent === '0') {
                addToCartButton.disabled = true;
            } else {
                addToCartButton.disabled = false;
            }
            } else if (selectedValue === 'L') {
                stockS.style.display = "none";
                stockM.style.display = "none";
                stockL.style.display = "inline";    
                if (stockL.textContent === '0') {
                addToCartButton.disabled = true;
            } else {
                addToCartButton.disabled = false;
            }
            }
        });
}

function setSize(size) {
    document.getElementById('product-size').value = size;
    // Get the stock value for the selected size
    var stock = document.querySelector('#stock-' + size).innerText;
    // Determine whether to start the quantity dropdown from 0 or 1 and if is more than 6
    var startValue = stock > 6 ? 1 : 0;
    if (stock > 0 && stock <= 6) {
        startValue = 1;
    }
    // Update the quantity dropdown based on the selected size's stock value
    var quantityDropdown = document.querySelector('#quantity');
    quantityDropdown.innerHTML = '';
    for (var i = startValue; i <= stock && i <= 6; i++) {
        var option = document.createElement('option');
        option.value = i;
        option.innerText = i;
        if (i === startValue) {
            option.selected = true;
        }
        quantityDropdown.appendChild(option);
    }
}

