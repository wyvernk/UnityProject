$(document).ready()
{
    SetMinDate();
};

function SetMinDate()
{
    var mindate = new Date();
    var month = mindate.getMonth() + 1;
    var year = mindate.getFullYear();
    if (month < 10) 
    {
      month = '0' + month;
    }
    document.getElementById("expiration").setAttribute("min", year + "-" + month);
}