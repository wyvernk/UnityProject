<?php 
    session_start();
    if (!isset($_SESSION["success"])) {
        header("location:index.php");
        exit();
    }
    else {
        unset($_SESSION["success"]);
    }
?>
<!DOCTYPE html>
<html lang="en">

<?php   
    include "new_includes/head.inc.php";
?>

<body>
    <?php 
        include "new_includes/nav.inc.php"
    ?>

    <main>
        <div class="container">
            <h1>Registration Successful!</h1>       
            <p>Sign in <a href="login.php">here</a>.</p>
       
        </div>
    </main>

    <?php 
        include "new_includes/footer.inc.php";
    ?>
</body>

</html>