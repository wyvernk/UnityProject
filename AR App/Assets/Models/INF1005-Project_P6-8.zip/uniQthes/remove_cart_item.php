<?php 
    if (!isset($_POST["product_id"])) {
        header("location:index.php");
        exit();
    }

    session_start();
    if (isset($_SESSION["cart"]) ) { // Remove butons wont even show as cart wont exist, but check just in case
        $updated_cart = array_filter($_SESSION["cart"], function($item) {
            return !($item["product_id"] == $_POST["product_id"] && $item["product_size"] == $_POST["product_size"]);
        });

        // Re-index the array keys
        $_SESSION["cart"] = array_values($updated_cart);
        
        header("location:shopping-cart.php");
    }
    
    
?>