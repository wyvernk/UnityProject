<?php 
	session_start ();
	if(!isset($_SESSION["login"])) {
        header("location:index.php");
        exit();
    }

    global $userID, $fname, $lname, $email, $address, $phonenumber, $errorMsg, $success;

    if (isset($_SESSION["edited"])) {
        $email = $_SESSION["email"];
        $fname = $_SESSION["edit_fname"];
        $lname = $_SESSION["edit_lname"];
        $address = $_SESSION["edit_address"];
        $phonenumber = $_SESSION["edit_phonenumber"];
    }
    else {
        // Retrieve account details from database
        $userID = $_SESSION["user_id"];

        // Create database connection.
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);

        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else
        {
            // Prepare the statement:
            $stmt = $conn->prepare("SELECT * FROM User WHERE UserID=?");

            // Bind & execute the query statement:
            $stmt->bind_param("i", $userID);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0)
            {
                // Note that email field is unique, so should only have
                // one row in the result set.
                $row = $result->fetch_assoc();
                $userID = $row["UserID"]; // extra measure just incase
                $fname = $row["fName"];
                $lname = $row["lName"];
                $email = $row["email"];
                $address = $row["address"];
                $phonenumber = $row["phone"];
            }
            else
            {
                echo "<h1>Unable to retrieve</h1>";
                $errorMsg = "Unable to retrieve account details, Try again later.";
                $success = false;
                $_SESSION["editAccErr"] = $errorMsg;
                header("location:profile.php");
            }
            
            $stmt->close();
        }
        $conn->close();
    }
    
    
?>
<!DOCTYPE html>
<html lang="en">

<?php 
    include "new_includes/head.inc.php"
?>

<body>
    <script defer src="js/validation.js"></script>
    <main>
        <?php 
            include "new_includes/nav.inc.php"
        ?>
        <section>
            <div class="container">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                        <div class="card shadow-2-strong" style="border-radius: 1rem;">
                            <div class="card-body p-5 text-center" style="background-color:#fdfdfd;">
                                <h2 class="mb-5">Edit Account</h2>
                                    <form method="post" action="update_account.php">                                               
                                        <span class="errMsg"><?php echo $_SESSION["formErr"]; ?></span><br>
                                        
                                        <!-- Email -->
                                        <div class="form-outline">
                                            <label for="email">Email</label>
                                            <input type="email" id="email" name="email" value="<?php echo $email; ?>" data-validation-required-message="Please enter your email" maxlength="45" disabled><br>
                                            <div class="invalid-feedback"></div>
                                        </div>

                                        <!-- First Name -->
                                        <div class="form-outline">
                                            <br><label for="fname">First name</label>
                                            <input type="text" id="fname" name="fname" value="<?php echo $fname; ?>" placeholder="First name" maxlength="45">
                                            <div class="invalid-feedback"></div>
                                            <span class="errMsg"><?php echo $_SESSION["fnameErr"]; ?></span><br>
                                        </div>
                                    
                                        <!-- Last Name -->
                                        <div class="form-outline">
                                            <br><label for="lname">Last name</label>
                                            <input type="text" id="lname" name="lname" value="<?php echo $lname; ?>" placeholder="Last name" data-validation-required-message="Please enter your last name" maxlength="45" required>
                                            <div class="invalid-feedback"></div>
                                            <span class="errMsg"><?php echo $_SESSION["lnameErr"]; ?></span><br>
                                        </div>

                                        <!-- Address-->
                                        <div class="form-outline">
                                            <br><label for="address">Address</label>
                                            <input type="text" id="address" name="address" value="<?php echo $address; ?>" placeholder="Address" maxlength="255">
                                            <span class="errMsg"><?php echo $_SESSION["addressErr"]; ?></span><br>
                                        </div>

                                        <!-- Phone -->
                                        <div class="form-outline">
                                            <br><label for="phone">Phone</label>
                                           <input type="tel" pattern="[0-9]{8}" class="form-control" id="phone" name="phone" maxlength="8" minlength="8"  value="<?php echo $phonenumber; ?>" data-validation-required-message="Please enter a valid phone number" placeholder="Phone number">
                                            <div class="invalid-feedback"></div>
                                            <span class="errMsg"><?php echo $_SESSION["phoneErr"]; ?></span><br>
                                        </div>     

                                        <br><button type="submit" class="site-btn btn-lg submit-btn">Comfirm Changes</button><br>
                                        <!-- <button type="button" onclick="location.href = 'profile.php';" class="registerbtn">Cancel</button> -->        
                                    </form>
                                <hr class="my-2">

                                <!-- Cancel Button -->
                                <button onclick="window.location.href='profile.php'" class="cancel-btn">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php 

            // Reset error messages
            unset($_SESSION["formErr"]);
            unset($_SESSION["fnameErr"]);
            unset($_SESSION["lnameErr"]);
            unset($_SESSION["addressErr"]);
            unset($_SESSION["phoneErr"]);
            unset($_SESSION["edited"]);

    ?>

    <?php 
        include "new_includes/footer.inc.php";
    ?>
</body>

</html>