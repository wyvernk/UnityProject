<!DOCTYPE html>

<html lang="en">

<?php
    // Start Session
    session_start();

    if (!isset($_POST["email"])) {
        header("location:index.php");
        exit();
    }

    function authenticateUser()
    {
        global $userID, $fname, $lname, $email, $address, $phonenumber, $pwd_hashed, $errorMsg, $success;

        // Create database connection.
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);

        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else
        {
            // Prepare the statement:
            $stmt = $conn->prepare("SELECT * FROM User WHERE
            email=?");

            // Bind & execute the query statement:
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            // Repopulate email field
            $_SESSION["email"] = $email;

            if ($result->num_rows > 0)
            {
                // Note that email field is unique, so should only have
                // one row in the result set.
                $row = $result->fetch_assoc();
                $userID = $row["UserID"];
                $fname = $row["fName"];
                $lname = $row["lName"];
                $email = $row["email"];
                $address = $row["address"];
                $phonenumber = $row["phone"];
                $pwd_hashed = $row["password"];
                $google = $row["google"];

                if ($google == 1) { // check if it is google account
                    $errorMsg = "Invalid email or password.";
                    $success = false;
                    $_SESSION["loginErr"] = $errorMsg;
                    header("location:login.php?err=1");
                }
                else {
                    // Check if the password matches:
                    if (!password_verify($_POST["pwd"], $pwd_hashed))
                    {
                        // Don't be too specific with the error message - hackers don't
                        // need to know which one they got right or wrong. :)
                        $errorMsg = "Invalid email or password.";
                        $success = false;
                        $_SESSION["loginErr"] = $errorMsg;
                        header("location:login.php?err=1");
                    }
                    else 
                    {
                        // Login Sucessful, create session variables
                        $_SESSION["login"] = "1";
                        $_SESSION["user_id"] = $userID;
                        $_SESSION["fname"] = $fname;
                        $_SESSION["lname"] = $lname;
                        $_SESSION["email"] = $email;
                        $_SESSION["address"] = $address;
                        $_SESSION["phonenumber"] = $phonenumber;
                        header("location:profile.php");
                    }
                }

            }
            else
            {
                $errorMsg = "Invalid email or password.";
                $success = false;
                $_SESSION["loginErr"] = $errorMsg;
                header("location:login.php?err=1");
            }
            
            $stmt->close();
        }
        $conn->close();
    }
?>

<main class="container">
    <?php

    $email = $lname = $errorMsg = $fname = $address = $phonenumber = "";

    $success = true;

    // Validate email
    if (empty($_POST["email"])) {
        $errorMsg .= "Email is required.<br>";
        $_SESSION["loginErr"] = $errorMsg;
        $success = false;
    } else {
        $email = sanitize_input($_POST["email"]);
        // Additional check to make sure e-mail address is well-formed.
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errorMsg .= "Invalid email format.<br>";
            $success = false;
        }
    }



    // Validate Password
    if (empty($_POST["pwd"])) {
        $errorMsg .= "Password is required.<br>";
        $_SESSION["loginErr"] = $errorMsg;
        $success = false;
    } else {
        $pwd = $_POST["pwd"];
        // Validate password from database
        authenticateUser();
          
    }


    //Helper function that checks input for malicious or unwanted content.
    function sanitize_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    // SUCCESSFUL FORM
    if (!$success) {
        header("location:login.php");
    }
    

    ?>

</main>

</html>