<!DOCTYPE html>
<?php
    session_start();
    // If cart is empty, redirect to cart
    if(!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
        header("location:shopping-cart.php");
    }

    $fname = $lname = $email = $address = $phonenumber = "";
       
    
    $totalcost = 0;
    $itemnames=array();
    $itemcosts=array();
    
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);
    
    $stmt = $conn->prepare("SELECT * FROM Product");
    $stmt->execute();
    $result = $stmt->get_result();

    $cart_checkout = $_SESSION["cart"];
    
    if($result->num_rows > 0)
    {
        while ($row = $result->fetch_assoc()) {
            array_push($itemnames, $row["productname"]);
            array_push($itemcosts, $row["price"]);
            $totalcost += $row["price"];
        }
        $totalcost = number_format((float)$totalcost, 2, '.', '');
    }
    
    $stmt->close();
    $conn->close();
?>



<html lang="en">
    
    <link rel="stylesheet" href="new_css/style.css">
        <!-- Custom JS -->
          <script defer src="js/validation.js"></script>
        <script defer src="js/payment.js"></script>
<?php 
    include "new_includes/head.inc.php"
?>
<main>
        
<body>
    <?php 
        include "new_includes/nav.inc.php";
    ?>
    
      <?php
      if(empty($_SESSION['fname']))
      {
        echo '<div class="container signin">
              <p>Want to save your details? <a href="register.php">Register here</a>.</p>
              </div>';
      }
    ?>
    <!-- Checkout Section Begin -->
    <section class="section">
        <div class="container">          
                <form action="process_payment.php" method="post">
                    <div class="row">
                        <div class="col-lg-8 col-md-6">

                            <span class="errMsg"><?php echo $_SESSION["formErr"]; ?></span><br>

                            <h1 class="checkout__title">Personal Details</h1>
                            <div class="checkout__input">
                                <p>Address<span>*</span></p>
                                <input class="form-control" type="text" name="address" placeholder="Address" maxlength="45" value="<?php echo $_SESSION["address"];?>" data-validation-required-message="Please enter your address" required>
                                <div class="invalid-feedback"></div>
                                <span class="errMsg"><?php echo $_SESSION["addressErr"]; ?></span>
                            </div>
                            <div class="checkout__input">
                                <p>Phone Number<span>*</span></p>
                                <input class="form-control" type="tel" name="phonenumber" inputmode="numeric" pattern="[0-9]{8}" maxlength="8" placeholder="Phone Number" value="<?php echo $_SESSION["phonenumber"];?>" data-validation-required-message="Please enter your phone number"  required>
                                <div class="invalid-feedback"></div>
                                <span class="errMsg"><?php echo $_SESSION["phonenumberErr"]; ?></span>
                            </div>                                  
                                <div class="checkout__input">
                                    <p>Email<span>*</span></p>
                                    <input class="form-control" type="email" name ="email" placeholder="Email" maxlength="45" value="<?php echo $_SESSION["email"];?>" data-validation-required-message="Please enter a valid email" required>
                                    <div class="invalid-feedback"></div>
                                    <span class="errMsg"><?php echo $_SESSION["emailErr"]; ?></span>
                                </div>
                            <div class="checkout__input">
                                <p>Order notes<span></span></p>
                                <input class="form-control" type="text" placeholder="Notes about your order, e.g. special notes for delivery." name="notes" maxlength="100">
                                <div class="invalid-feedback"></div>
                            </div>
                            
                            <h1 class="checkout__title">Billing Details</h1>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>First Name<span>*</span></p>
                                        <input class="form-control" type="text" name="fname" placeholder="First name on card" maxlength="45" value="<?php echo $_SESSION["fname"];?>" data-validation-required-message="Please enter first name on card" required>
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $_SESSION["fnameErr"]; ?></span>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="checkout__input">
                                        <p>Last Name<span>*</span></p>
                                        <input class="form-control" type="text" name="lname" placeholder="Last name on card" maxlength="45" value="<?php echo $_SESSION["lname"];?>" data-validation-required-message="Please enter last name on card" required>
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $_SESSION["lnameErr"]; ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                            <div class="col-lg-6">
                                <div class="checkout__input">
                                  <p>Card Number<span>*</span></p>
                                  <input class="form-control" type="tel" placeholder="Card Number" pattern="[0-9]{16}" maxlength="16" name="card_number" value="<?php echo $_SESSION["cardNo"];?>" data-validation-required-message="Please enter a valid card number" required>
                                   <div class="invalid-feedback"></div>
                                   <span class="errMsg"><?php echo $_SESSION["cardErr"]; ?></span>
                                 </div>
                            </div>
                           
                                <div class="col-lg-2">
                                    <div class="checkout__input">
                                        <p>CVV<span>*</span></p>
                                        <input class="form-control" type="tel" placeholder="CVV" pattern="[0-9]{3}" maxlength="3" name="cvv" value="<?php echo $_SESSION["cardCvv"];?>" data-validation-required-message="Please enter a valid cvv" required>
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $_SESSION["cvvErr"]; ?></span>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="checkout__input">
                                        <p>Expiration<span>*</span></p>
                                        <input class="form-control" type="month" placeholder="Expiration Date" id="expiration" min="2023-02" name="expiration" value="<?php echo $_SESSION["cardExp"];?>" data-validation-required-message="Please enter expiration date" required>
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $_SESSION["expErr"]; ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>    
                        
                        <div class="col-lg-4 col-md-6">
                            <div class="checkout__order">
                                <h2 class="order__title">Your order</h2>
                                <div class="checkout__order__products">Product <span>Total</span></div>
                                <ul class="checkout__total__products">
                                    <?php                  
                                        foreach ($cart_checkout as $item) {
                                            $product_name = $item["product_name"];
                                            $product_size = $item["product_size"];
                                            // Calculate Subtotal
                                            $price = $item["product_price"];
                                            $quantity = $item["quantity"];
                                            $item_total = $price * $quantity;   // calculate the total price of the item
                                            $subtotal += $item_total;          // add the item total to the running subtotal

                                            // echo "<li> ".($index+1).". x" . $quantity . " " . $product_name . "(". $product_size . ")" . "<span>" . $item_total . "</span></li>";
                                            echo "<li>" . $quantity . "x " . $product_name . "(". $product_size . ")" . "<span>" . $item_total . "</span></li>";
                                            $index++;
                                        }
                                        $_SESSION["subtotal"] = $subtotal;
                                    ?>
                                </ul>
                                <ul class="checkout__total__all">
                                    <?php   
                                        echo "<li>Total <span>$subtotal</span></li>";
                                    ?>
                                </ul>
                                <p>Please ensure your order, personal particulars and billing details are correct.</p>
                                <button type="submit" class="site-btn">PLACE ORDER</button>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </section>
    <!-- Checkout Section End -->

    <?php 
      
            unset(
                $_SESSION["formErr"],
                $_SESSION["fnameErr"],
                $_SESSION["lnameErr"],
                $_SESSION["emailErr"],
                $_SESSION["addressErr"],
                $_SESSION["phonenumberErr"],
                $_SESSION["cardErr"],
                $_SESSION["cvvErr"],
                $_SESSION["expErr"],
                );

                if(!isset($_SESSION["login"])) {
                    unset(
                        $_SESSION["fname"],
                        $_SESSION["lname"],
                        $_SESSION["email"],
                        $_SESSION["address"],
                        $_SESSION["phonenumber"],
                        $_SESSION["cardNo"],
                        $_SESSION["cardCvv"],
                        $_SESSION["cardExp"]
                    );
                }
        
    ?>
</main>
    <?php 
        include "new_includes/footer.inc.php";
    ?>
</body>

</html>