<?php
$name = $email = $message = $errorMsg = "";
$success = true;

$date = date("Y-m-d");
//sanitize name
//check if empty
if (empty($_POST["name"]))
{
    $errorMsg .= "name is required.<br>";
    $success = false;
}
else
{  
   //sanitise last name and add space
  $name =  sanitize_input($_POST["name"]);
}


//sanitise email
if (empty($_POST["email"]))
{
    $errorMsg .= "Email is required.<br>";
    $success = false;
}
else
{
    $email = sanitize_input($_POST["email"]);
    // Additional check to make sure e-mail address is well-formed.
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
    {
        $errorMsg .= "Invalid email format.<br>";
        $success = false;
    }
}


//sanitize message
if (empty($_POST["message"]))
{
    $errorMsg .= "Message is required.<br>";
    $success = false;
}
else
{  
   //sanitise last name and add space
  $message =  sanitize_input($_POST["message"]);
}

function saveMessageToDB()
{
    global $name, $email, $message, $errorMsg, $date;
    // Create database connection.
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);
    // Check connection
    if ($conn->connect_error)
    {
        $errorMsg = "Connection failed: " . $conn->connect_error;
        $success = false;
    }
    else
    {
        // Prepare the statement:
       $stmt = $conn->prepare("INSERT INTO Enquiries (enquirerName, enquirerEmail,
       enquiry, enquiryDate) VALUES (?, ?, ?, ?)");
       // Bind & execute the query statement:
       $stmt->bind_param("ssss", $name, $email, $message, $date);

       if (!$stmt->execute())
       {
           $errorMsg = "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
           $success = false;
       }
        $stmt->close();
    }
    $conn->close();
    }

 //Helper function that checks input for malicious or unwanted content.
function sanitize_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

?>

<!DOCTYPE html>
<html lang="en">

<?php 
    include "new_includes/head.inc.php"
?>
<body>
<main>
<?php 
    include "new_includes/nav.inc.php"
?>

<!--Results of form submission-->
 <div class="container">
            <div class="row">
                <div class= "section-title">
<?php
        if ($success)
        {
            echo "<h1>Thank you for your enquiry " .$name. "!</h1>";
            echo "<p>We will get back to you as soon as possible through the email address " . $email.".</p>";
            echo "<br>";
            echo '<a href="about.php" class="site-btn">Back</a>';
            saveMessageToDB();
        }
        
        else
        {
            echo "<h1>Oh No!</h1>";
            echo "<h2>The following input errors were detected:</h2>";
            echo "<p>" . $errorMsg . "</p>";
            echo "<p>Please enter your enquiries again if needed</p>";
            echo "<br>";
            echo '<a href="about.php" class="site-btn">Back</a>';
        }
?>
                </div>
        </div>
</div>

<br>
</main>
 <?php 
        include "new_includes/footer.inc.php";
    ?>
</body>

</html>
