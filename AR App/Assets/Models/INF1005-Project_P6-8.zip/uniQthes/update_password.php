<!DOCTYPE html>

<html lang="en">

<?php
    // Start Session
    session_start();

    if (!isset($_POST["currPwd"])) {
        header("location:index.php");
        exit();
    }

    // Authenticate Current Password function
    function authenticateCurrPassword()
    {
        global $pwd_hashed, $errorMsg, $conn;
        $authenticated = true; // local variable

        // Create database connection.
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);

        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $authenticated = false;
            $_SESSION["errorMsg"] = $errorMsg;
        }
        else
        {
            // Prepare the statement:
            $stmt = $conn->prepare("SELECT * FROM User WHERE
            UserID=?");

            // Bind & execute the query statement:
            $stmt->bind_param("i", $_SESSION["user_id"]);
            $stmt->execute();
            $result = $stmt->get_result();


            if ($result->num_rows > 0)
            {
                $row = $result->fetch_assoc();
                $pwd_hashed = $row["password"]; // Fetch password hash
                
                // Check if the password matches:
                if (!password_verify($_POST["currPwd"], $pwd_hashed))
                {
                    $errorMsg = "Invalid Password";
                    $authenticated = false;
                    $_SESSION["currPwdErr"] = $errorMsg;
                    header("location:change_password.php");
                }

            }
            else
            {
                $errorMsg = "There was a problem while trying to change password. Try again later";
                $authenticated = false;
                $_SESSION["errorMsg"] = $errorMsg;
                header("location:change_password.php");
            }
            
            $stmt->close();
        }
        

        return $authenticated;
    }


    // Validate New Password function
    function validateNewPwd() {
        global $newPwd, $new_pwd_hashed, $pwd_confirm, $pwdErr, $pwdConfirmErr;
        $validated = true; // local variable

       
        // Validate Password
        if (empty($_POST["newPwd"])) {
            $pwdErr .= "*Password is required.<br>";
            $validated = false;
        } else {
            $newPwd = $_POST["newPwd"];
            // Validate password strength
            $uppercase    = preg_match('@[A-Z]@', $newPwd);
            $lowercase    = preg_match('@[a-z]@', $newPwd);
            $number       = preg_match('@[0-9]@', $newPwd);
            $specialchars = preg_match('@[^\w]@', $newPwd);

            if (!$uppercase || !$lowercase || !$number || !$specialchars || strlen($newPwd) < 8) {
                $pwdErr .= "*Password does not contain:<br>";
                if (!$uppercase) {
                    $pwdErr .= "-uppercase letters<br>";
                }
                if (!$lowercase) {
                    $pwdErr .= "-lowercase letters<br>";
                }
                if (!$number) {
                    $pwdErr .= "-numbers<br>";
                }
                if (!$specialchars) {
                    $pwdErr .= "-special characters<br>";
                }
                if (strlen($newPwd) < 8) {
                    $pwdErr .= "-at least 8 characters long<br>";
                }
                $validated = false;
            }
            
        }

        // Validate Confirm Password
        if (empty($_POST["cfmPwd"])) {
            $pwdConfirmErr .= "*Confirm password required.<br>";
            $validated = false;
        } else if (!empty($_POST["newPwd"])) {
            $pwd_confirm = $_POST["cfmPwd"];

            // Check if passwords match
            if ($pwd_confirm !== $newPwd) {
                $pwdConfirmErr .= "*Passwords do not match.<br>";
                $validated = false;
            }
            else {
                $new_pwd_hashed = password_hash($newPwd, PASSWORD_DEFAULT);
                // store hash in database for validation later
            }
        }

        return $validated;
    }
?>

<main class="container">
    <?php
        $errorMsg = "";

        // Validate Password
        if (empty($_POST["currPwd"])) {
            $errorMsg .= "Password is required<br>";
            $_SESSION["currPwdErr"] = $errorMsg;

        } else {
            // Validate password from database
            if (authenticateCurrPassword()) {
                // Validate password
                if (validateNewPwd()) {
                    // Update Password in Database
                    // Prepare the statement:
                    $update_stmt = $conn->prepare("UPDATE User SET password=? WHERE UserID=?");

                    // Bind & execute the query statement:
                    $update_stmt->bind_param("si", $new_pwd_hashed, $_SESSION["user_id"]);
                    if (!$update_stmt->execute())
                    {
                        $errorMsg = "Execute failed: (" . $update_stmt->errno . ") " . $update_stmt->error;
                        $_SESSION["errorMsg"] = $errorMsg;
                        header("location:change_password.php");
                    }
                    $update_stmt->close();
                    header("location:profile.php");
                    
                }
                else {
                    $_SESSION["pwdErr"] = $pwdErr;
                    $_SESSION["pwdConfirmErr"] = $pwdConfirmErr;
                    header("location:change_password.php");
                }
            }
            else {
                header("location:change_password.php"); // redirect back to show errorMsg session variable
            }
        }

        $conn->close();
    ?>

</main>

</html>