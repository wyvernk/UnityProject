<?php
session_start();

// Check if user is logged in as an admin
if (!isset($_SESSION["AdminID"]) || $_SESSION["admin_login"] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Create database connection.
$config = parse_ini_file('../../private/db-config.ini');
$conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the User ID from the URL parameter
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

// Prepare and execute the delete statement
$stmt = $conn->prepare("DELETE FROM User WHERE UserID = ?");
$stmt->bind_param("i", $id);    

if ($stmt->execute()) {
    // Redirect back to adminpage.php
    header("Location: adminpage.php?tab=Customers%20Information");
    exit();
} else {
    echo "Error deleting record: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
