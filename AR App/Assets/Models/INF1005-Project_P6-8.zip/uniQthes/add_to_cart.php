<?php
    session_start();
    if (!isset($_GET["product_id"])) {
        header("location:index.php");
        exit();
    }

    $_SESSION["message"] = "Added to cart";  

    // If cart exists
    if (isset($_SESSION["cart"])) {

        $found_item = false;
        $cart_item_maxed = false;
        $enough_stock = false;

        // Open connection
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);
        
        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else {
            $stmt = $conn->prepare("SELECT * FROM Product WHERE ProductID=? AND size=?");
            // Start to loop to check if cart has item
            foreach ($_SESSION["cart"] as $key => $item) {  
                if ($item["product_id"] == $_GET["product_id"] && $item["product_size"] == $_GET["product_size"]) {
                    $found_item = true;

                    // Check if add, will be more than 6
                    if (($item["quantity"]+ $_GET["quantity"]) > 6) {
                        $_SESSION["message"] = "Maximum 6 allowed in cart"; 
                    }
                    else { // CHECK STOCK

                        // Translate size first
                        if($item["product_size"] == "S") {
                            $size = "small";
                        }
                        else if($item["product_size"] == "M") {
                            $size = "med";
                        }
                        else {
                            $size = "large";
                        }

                        // Bind and execute SQL statement
                        $stmt->bind_param("is", $item["product_id"], $size);    
                        $stmt->execute();

                        // Retrieve result from query
                        $result = $stmt->get_result();           
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $stock = $row["stock"];

                            // Check if stock is more than GET quantity + SESSION cart quantity
                            if ($stock >= ($_GET["quantity"] + $_SESSION["cart"][$key]["quantity"])) {
                                // Update cart quantity
                                $_SESSION["cart"][$key]["quantity"] += $_GET["quantity"];
                                $_SESSION["message"] = "Quantity updated in cart";  
                            }
                            else {
                                $_SESSION["message"] = "Not enough stock";  
                            }
                        }
                    }                
                    break;
                }
            }

            if (!$found_item) {
                // check stock from using GET product id and GET size

                // Translate size first
                if($_GET["product_size"] == "S") {
                    $size = "small";
                }
                else if($_GET["product_size"] == "M") {
                    $size = "med";
                }
                else {
                    $size = "large";
                }

                // Bind and execute SQL statement
                $stmt->bind_param("is", $_GET["product_id"], $size);    
                $stmt->execute();

                // Retrieve result from query
                $result = $stmt->get_result();           
                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $stock = $row["stock"];

                    // Check if stock is more than GET quantity + SESSION cart quantity
                    if ($stock >= $_GET["quantity"]) {
                        // Add new item to cart
                        $count = count($_SESSION["cart"]);      // count number of items in the cart
            
                        $item_array = array(                    // Create new item array
                            "product_id"=>$_GET["product_id"],
                            "product_img"=>$_GET["product_img"],
                            "product_name"=>$_GET["product_name"],
                            "product_price"=>$_GET["product_price"],
                            "product_desc"=>$_GET["product_desc"],
                            "product_size"=>$_GET["product_size"],
                            "quantity"=>$_GET["quantity"]
                        );
            
                        $_SESSION["cart"][$count] = $item_array; // append item to cart
                       
                    }
                    else {
                        $_SESSION["message"] = "Not enough stock";  
                    }
                }
            }

            $stmt->close();
      
        }
   
        $conn->close();
        
    }
    else {
        $item_array = array(                    // create cart array
            "product_id"=>$_GET["product_id"],
            "product_img"=>$_GET["product_img"],
            "product_name"=>$_GET["product_name"],
            "product_price"=>$_GET["product_price"],
            "product_desc"=>$_GET["product_desc"],
            "product_size"=>$_GET["product_size"],
            "quantity"=>$_GET["quantity"]
        );

        $_SESSION["cart"][0] = $item_array;     // Create cart session and insert first item
        $_SESSION["cart_count"] = 1; 
    }

    header('Location: ' . $_SERVER['HTTP_REFERER']);

?>

