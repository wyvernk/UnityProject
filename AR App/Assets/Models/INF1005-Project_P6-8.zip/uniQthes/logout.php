<?php

session_start();

// ... initialize Google_Client object ...
require_once __DIR__ . '/../vendor/autoload.php';


// init configuration 
$clientID = '66853079866-dcf64ho0621jbr2m9cfhk7pa2em2rd9l.apps.googleusercontent.com';
$clientSecret = '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';
$redirectUri = 'http://uniqlothes.xyz';
  
// create Client Request to access Google API 
$client = new Google_Client();
$client->setClientId($clientID);
$client->setClientSecret($clientSecret);
$client->setRedirectUri($redirectUri);
$client->addScope("email");
$client->addScope("profile");


if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
    // revoke the access token
    $client->revokeToken($_SESSION['access_token']);

    // unset session variables
    unset($_SESSION['access_token']);
}

unset($_SESSION['email']);
unset($_SESSION['fname']);
unset($_SESSION['login']);
session_destroy();


// redirect to the login page
header('Location:login.php');
exit();

?>
