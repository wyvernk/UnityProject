<?php
  session_start();

  // Check if user is logged in as an admin
  if (!isset($_SESSION["AdminID"]) || $_SESSION["admin_login"] !== true) {
    header("Location: admin_login.php");
    exit();
  }

  // Create database connection.
  $config = parse_ini_file('../../private/db-config.ini');
  $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Retrieve Product data
  if (isset($_GET['id']) && !empty($_GET['id']) && isset($_GET['size']) && !empty($_GET['size'])) {
    $ProductID = sanitize_input($_GET['id']);
    $size = sanitize_input($_GET['size']);
    $stmt = $conn->prepare("SELECT * FROM Product WHERE ProductID = ? AND size = ?");
    $stmt->bind_param("is", $ProductID, $size);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
      $row = $result->fetch_assoc();
    } else {
      echo "Product not found";
      exit();
    }
  } else {
    echo "Invalid request";
    exit();
  }
     
  // Handle form submission
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $CategoryID = sanitize_input($_POST["CategoryID"]);
    $productName = sanitize_input($_POST["productName"]);
    $price = sanitize_input($_POST["price"]);
    $stock = sanitize_input($_POST["stock"]);
    $productImgPath = sanitize_input($_POST["productImgPath"]);
    $productDesc = sanitize_input($_POST["productDesc"]);
    $rating = sanitize_input($_POST["rating"]);
     
    // Update product data in database using prepared statement
    $stmt = $conn->prepare("UPDATE Product SET CategoryID=?, productName=?, "
            . "price=?, stock=?, productImgPath=?, productDesc=?, rating=? "
            . "WHERE"
            . " ProductID=? AND size=?");
    $stmt->bind_param("isdissiis", $CategoryID, $productName, $price, $stock,
            $productImgPath, $productDesc, $rating, $ProductID, $size);
    if ($stmt->execute()) {
      echo "Product updated successfully";  
      echo '<script>window.close();</script>';
      exit();
    } else {
      echo "Error updating product: " . $conn->error;
    }
  }
    //Helper function that checks input for amalicious or unwanted content.
    function sanitize_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
      }
?>

<head>
  <title>Edit Product</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="js/openForm.js"></script>
</head>

<body>
  <div class="container">
    <h2>Edit Product</h2>
    <form method="post">
      <div class="form-group">
        <label for="CategoryID">Category ID:</label>
        <input type="int" class="form-control" id="CategoryID" name="CategoryID" value="<?php echo htmlspecialchars($row['CategoryID']); ?>" required>
      </div>
      
      <div class="form-group">
        <label for="productName">Product Name:</label>
        <input type="text" class="form-control" id="productName" name="productName" value="<?php echo htmlspecialchars($row['productName']); ?>" required>
      </div>    
      <div class="form-group">
        <label for="price">Price:</label>
        <input type="number" class="form-control" id="price" name="price" value="<?php echo htmlspecialchars($row['price']); ?>" required>
      </div>
       <div class="form-group">
        <label for="stock">Stock:</label>
        <input type="text" class="form-control" id="stock" name="stock" value="<?php echo htmlspecialchars($row['stock']); ?>" required>
      </div>     
      <div class="form-group">
        <label for="productImgPath">Product Image:</label>
        <div class="input-group">
          <input type="text" class="form-control" id="productImgPath" name="productImgPath" value="<?php echo htmlspecialchars($row['productImgPath']); ?>">
          <div class="input-group-append">
            <button type="button" class="btn btn-outline-secondary" id="selectImageBtn">Select Image</button>
          </div>
        </div>
      </div>
            <input type="hidden" class="form-control" id="productImgPath" name="productImgPath" value="<?php echo htmlspecialchars($row['productImgPath']); ?>" required>
          </div>
        </div>
      <div class="form-group">
        <label for="productDesc">Product Description:</label>
        <input type="text" class="form-control" id="productDesc" name="productDesc" value="<?php echo htmlspecialchars($row['productDesc']); ?>" required>
      </div>      
      <div class="form-group">
        <label for="rating">Rating:</label>
        <input type="int" class="form-control" id="rating" name="rating" value="<?php echo htmlspecialchars($row['rating']); ?>" required>
      </div>

      <button type="submit" class="btn btn-primary">Update Product</button>
      <button type="button" class="btn btn-secondary" onclick="window.close()">Go Back</button>

    </form>
  </div>

</body>
</html>

<?php
  $conn->close();
?>