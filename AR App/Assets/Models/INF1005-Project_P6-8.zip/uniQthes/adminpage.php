    <?php
        session_start();

        // Check if user is logged in as an admin
        if (!isset($_SESSION["AdminID"]) || $_SESSION["admin_login"] !== true) {
            header("Location: admin_login.php");
            exit();
        }
        // Logout functionality
        if (isset($_POST['logout'])) {
            unset($_SESSION["AdminID"]);
            $_SESSION["admin_login"] = false;
            header("Location: admin_login.php");
        exit();
    }
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>Admin Page</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <link rel="stylesheet" type="text/css" href="new_css/style.css">
      <style> .header { background-color: #f1f1f1; padding: 20px; text-align: center;}
              #logout-btn { float: right; margin-top: -5px;} .col-sm-3 { height: 100%; background-color: #f1f1f1;
              padding-top: 20px; margin-top: 20px; width: 12.5%;} .col-sm-9 { margin-top: 20px;} @media (max-width: 767px) {
              .col-sm-3 {display: none;}.col-sm-9 { margin-top: 20px;}} </style>
    </head>
    <body>
    <main>
      <div class="container-fluid adminpage">
        <div class="row">
          <div class="col-sm-12 header">
            <!-- Add your header content here -->
            <h1>Welcome to the UniQthes' Admin Page</h1>
            <form method="post">
                <button id="logout-btn" name="logout" class="btn btn-danger" style="background-color:#d9534f;color:#000000;font-size:14px;">Logout</button>
            </form>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-3">
            <!-- Add your sidebar content here -->
            <ul class="nav nav-pills nav-stacked">
              <li><a href="?page=admin_customer_table">Users</a></li>
              <li><a href="?page=admin_product_table">Product</a></li>
              <li><a href="?page=admin_ordermanagement">Order</a></li>
              <li><a href="?page=admin_enquiries">Enquiries</a></li>
            </ul>
          </div>
          <div class="col-sm-9">
            <!-- Add your main content here -->
            <?php
              $page = isset($_GET['page']) ? $_GET['page'] : 'admin_customer_table';
              if ($page == 'admin_customer_table') {
                  include 'admin_customer_table.php';
              } else if ($page == 'admin_product_table') {
                  include 'admin_product_table.php';
              } else if ($page == 'admin_ordermanagement') {
                  include 'admin_ordermanagement.php';
              } else if ($page == 'admin_enquiries') {
                  include 'admin_enquiries.php';
              } 
              else {
                  // handle invalid page request here
              }
            ?>
          </div>
        </div>
      </div>
         <?php include 'new_includes/footer.inc.php'; ?>

    </main>
    </body>
    </html>
