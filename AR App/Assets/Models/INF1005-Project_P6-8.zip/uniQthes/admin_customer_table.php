<?php
    session_start();
    
    // Check if user is logged in as an admin
    if (!isset($_SESSION["AdminID"]) || $_SESSION["admin_login"] !== true) {
        header("Location: admin_login.php");
        exit();
    }
?>
<html lang="en">
<title>Customers Information</title>
<script src="js/openForm.js"></script>
<link rel="stylesheet" href="new_css/style.css">
<table class="admintable">
  <thead>
    <tr>
      <th>Customer ID</th>
      <th>Email</th>
      <th>First Name</th>
      <th>Last Name</th>
      <th>Phone</th>
      <th>Address</th>
      <th>Status</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    <?php
      // Create database connection.
      $config = parse_ini_file('../../private/db-config.ini');
      $conn = new mysqli($config['servername'], $config['username'],
      $config['password'], $config['dbname']);

      // Check connection
      if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
      }
      
      $stmt = $conn->prepare("SELECT UserID, email, fName, lName, phone, address, status FROM User");
      // Bind & execute the query statement:
      $stmt->execute();
      $result = $stmt->get_result();
      

      if ($result->num_rows > 0) {
        // Output data of each row
        while($row = $result->fetch_assoc()) {
          echo "<tr>";
          echo "<td>" . $row["UserID"] . "</td>";
          echo "<td>" . $row["email"] . "</td>";
          echo "<td>" . $row["fName"] . "</td>";
          echo "<td>" . $row["lName"] . "</td>";
          echo "<td>" . $row["phone"] . "</td>";
          echo "<td>" . $row["address"] . "</td>";
          echo "<td>" . $row["status"] . "</td>";
          echo "<td><a href='admindelete.php?id=" . $row["UserID"] . "' onclick='return confirm(\"Are you sure you want to delete this customer?\")'>Delete</a></td>";
          echo "</tr>";
        }
      } else {
        echo "0 results";
      }

      $conn->close();   
    ?>
  </tbody>
</table>
</html>