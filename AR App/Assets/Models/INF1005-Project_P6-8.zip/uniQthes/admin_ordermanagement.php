<?php

 // Check if user is logged in as an admin
    if (!isset($_SESSION["AdminID"]) || $_SESSION["admin_login"] !== true) {
        header("Location: admin_login.php");
        exit();
    }

if(isset($_POST['status_dropdown']) and isset($_POST['status_button'])) {
       ChangeOrderStatus();
}

function ChangeOrderStatus()
{
    $orderid = $_POST['status_button'];
    $orderstatus = $_POST['status_dropdown'];
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);
    
    
    $stmt = $conn->prepare("SELECT * FROM Orders WHERE OrderID =?");
    $stmt->bind_param("i", $orderid);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows > 0)
    {
        $row = $result->fetch_assoc();
      

        $queryalter = "UPDATE Orders SET orderStatus = ? WHERE OrderID = ?";
        $stmt = $conn->prepare($queryalter);
        $stmt->bind_param("si", $orderstatus, $orderid);
        $stmt->execute();
    }
    $stmt->close();
    $conn->close();
}

function PrintAllOrders()
{
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);
    
    $stmt = $conn->prepare("SELECT * FROM Orders");
    $stmt->execute();
    $result = $stmt->get_result();
    
     
    while($row = $result->fetch_assoc())
    {      
        $orderid = $row["OrderID"];
        $orderstatus =  $row["orderStatus"];
        echo     '<div class="card_item">';
        echo     '<div class="row">';
            echo     '<div class="col-lg-12">';
            echo     "<h2>Order ID: #". $row["OrderID"] . "</h2>";
            echo     "</div>";
        echo     "</div>";
        echo     '<div class="row">';
            echo     '<div class="col-lg-4">';       
            echo     "<h3>Details: </h3>";
            echo     "<p>Name: ". $row["customerName"] ."</p>";
            echo     "<p>Email: ". $row["customerEmail"] ."</p>";
            echo     "<p>Phone Number: ". $row["customerPhone"] ."</p>";
            echo     "<p>Address: ". $row["deliveryAddress"] ."</p>";
            echo     "<p>Order Date: ". $row["orderDate"] ."</p>";
        echo     "</div>";
        
        echo     '<div class="col-lg-4">';
            echo     "<h3>Order: <span>Price:</span></h3>";      
            
        $stmt = $conn->prepare("SELECT * FROM OrderList WHERE OrderList.OrderID = ?");
        $stmt->bind_param("i", $orderid);
        $stmt->execute();
        $orderresult = $stmt->get_result();
            
            $pricetotal = 0;
            while($row2 = $orderresult->fetch_assoc())
            {
                echo "<p>" . $row2["productName"] . "(". $row2["size"] . ") x" . $row2["quantity"] . "<span>$" . $row2["price"] . "</span></p>";  
                $pricetotal += $row2["price"] * $row2["quantity"];
            }
              echo "<br>";
              $pricetotal = number_format((float)$pricetotal, 2, '.', '');
            echo     "<p>Total: <span>$" .$pricetotal . "</span></p>";         
        echo "</div>";
            
            echo     '<div class="col-lg-4">';            
                echo     "<h3>Status: " . $orderstatus . "</h3>";                     
            echo     "</div>";
        echo "</div>";
        
        echo  '<div class="row">';
            echo   '<div class="col-lg-12">';
            echo   '<div class="center_text">';
            echo   "<p>Notes: ". $row["orderNotes"] ."</p>";
                echo   "<form method='post'>";
                echo    " <label>Change Status:
                        <select name='status_dropdown' class='status-select'>
                          <option value='Pending'>Pending</option>
                          <option value='Shipping'>Shipping</option>
                          <option value='Delivered'>Delivered</option>
                          <option value='Cancelled'>Cancelled</option>
                          <option value='Refunded'>Refunded</option>
                        </select></label>";
                echo   "<input type='hidden' name='status_button' class='site-btn' value={$orderid}>";              
                echo   "<button type='submit' class='site-btn'>Change Status</button>";
                echo   "</form>";
             echo   "</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";     
         
        echo "<hr>";
    }
    $stmt->close();
    $conn->close();
}
?>

     <link rel="stylesheet" href="new_css/style.css">
    <!-- Contact Section Begin -->
    <section class="section">
        <div class="container">                
                    <div class="section-title">
                        <h1>Order Management</h1>
                    </div>                                         
                        <?php
                            PrintAllOrders();
                        ?>
    </div>
    </section>