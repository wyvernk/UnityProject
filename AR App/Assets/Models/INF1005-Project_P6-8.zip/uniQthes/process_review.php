<?php
session_start();
$ReviewText = $ProductID = $ReviewID = $Rating = $errorMsg =  "";
$success = true;
$Date = date("Y-m-d");

if(!empty($_POST["Review"]) && isset($_POST["add_review_product_id"]) && isset($_POST["rating"]))
{
    $ProductID = sanitize_input($_POST['add_review_product_id']);
    $ReviewText = sanitize_input($_POST["Review"]);
    $Rating = sanitize_input($_POST["rating"]);
    SaveReviewToDB();
}

else if(isset($_POST['delete_review_id']) && isset($_POST['delete_product_id'])) {
    $ReviewID = $_POST['delete_review_id'];
    $ProductID = $_POST['delete_product_id'];
    DeleteReview();
}

else if(!empty($_POST["updated_review_text"]) && isset($_POST["update_review_product_id"]) && isset($_POST["edit_rating"]))
{    
    $ProductID = $_POST["update_review_product_id"];
    $ReviewID = $_POST["update_review_id"];
    $ReviewText = sanitize_input($_POST["updated_review_text"]);
    $Rating = sanitize_input($_POST["edit_rating"]);
    EditReview();
}

function SaveReviewToDB()
{       
        global $ProductID, $ReviewText, $Rating, $Date;
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);

        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else
        {
            // Prepare the statement to inset into Orders:
            $review_stmt = $conn->prepare("INSERT INTO Reviews (UserID, ProductID,
            reviewText, reviewRating, reviewDate) VALUES (?, ?, ?, ?, ?)");

            // Bind & execute the query statement:
            $review_stmt->bind_param("iisis", $_SESSION["user_id"],  $ProductID, $ReviewText, $Rating, $Date);

            if (!$review_stmt->execute())
            {
                $errorMsg = "Execute failed: (" . $review_stmt->errno . ") " . $review_stmt->error;
                $success = false;
            }
            $review_stmt->close();
        }
        $conn->close();
}

function EditReview()
{       
        global $ReviewID, $ReviewText, $ProductID, $Rating, $Date;
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);

        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else
        {
            // Prepare the statement to inset into Orders:
            $review_stmt = $conn->prepare("UPDATE Reviews SET reviewText=?, reviewRating=?, reviewDate=? WHERE ReviewID=?");

            // Bind & execute the query statement:
            $review_stmt->bind_param("sisi", $ReviewText, $Rating, $Date,$ReviewID);
            $review_stmt->execute();
            $review_stmt->close();
        }
        $conn->close();
}

function DeleteReview()
{       
        global $ReviewID;
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);

        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else
        {
            // Prepare the statement to inset into Orders:
            $review_stmt = $conn->prepare("DELETE FROM Reviews WHERE ReviewID=?");

            // Bind & execute the query statement:
            $review_stmt->bind_param("i", $ReviewID);
            $review_stmt->execute();
            $review_stmt->close();
        }
        $conn->close();
}

//Helper function that checks input for malicious or unwanted content.
function sanitize_input($data)
{
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}

function UpdateProductRating()
{
        global $ProductID;
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);

        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else
        {
            // Prepare the statement to inset into Orders:
            $review_stmt = $conn->prepare("Select reviewRating FROM Reviews where ProductID=?");

            // Bind & execute the query statement:
            $review_stmt->bind_param("i", $ProductID);
            $review_stmt->execute();
            
            $result = $review_stmt->get_result();
            if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $TotalRating += $row["reviewRating"];
            }
            $AverageRating = $TotalRating/$result->num_rows;
            }
            else
            {
                $AverageRating=0;
            }
            
            $updatereview_stmt = $conn->prepare("UPDATE Product SET rating=? where ProductID=?");
            $updatereview_stmt->bind_param("ii", $AverageRating, $ProductID);
            $updatereview_stmt->execute();
            
            
            $review_stmt->close();
            $updatereview_stmt->close();
        }
        $conn->close();
}

if ($success)
{
    UpdateProductRating();
    header("Location:productDetails.php?myid=$ProductID");
}

else
{
        echo "<h2>Oh No!</h2>";
        echo "<h3>The following input errors were detected:</h3>";
        echo "<p>" . $errorMsg . "</p>";
}

?>