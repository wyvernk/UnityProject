<!DOCTYPE html>
<html lang="en">

    <?php include "client.php"; ?>
    <?php include "Oauth.php"; ?>

    <?php include "new_includes/head.inc.php" ?>
     <body>
<main>
   
        

        <?php include "new_includes/nav.inc.php" ?>
        <?php include "fetchProduct.php" ?>
        <section class="banner">
        <div id="carouselExampleCaptions" class="carousel slide">
            <div class="carousel-indicators">
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
            </div>
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="img/hero/hero-1.jpg" class="d-block w-100" alt="...">
                    <div class="carousel-caption ">
                        <h2>Summer Collection</h2>
                        <p>Get ready to beat the heat in style with our summer collection!</p> 
                        <a href="products.php" class="btn btn-primary">Shop NOW!</a>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="img/hero/hero-2.jpg" class="d-block w-100" alt="...">
                    <div class="carousel-caption">
                        <h2>Summer Collection</h2>
                        <p>Stay stylish and comfortable this summer with our new collection.</p>
                        <a href="products.php" class="btn btn-primary">Shop NOW!</a>
                    </div>
                </div>
            </div>

            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div> 
            </section>
            <section class="section-products">
                <div class="container">
                    <div class="row justify-content-center text-center">
                        <div class="col-md-8 col-lg-6">
                            <div class="header">
                                <h2>Popular Products</h2>
                                <p>Featured Product</p>                                
                            </div>
                        </div>
                    </div>
                    <div id="carouselExampleControlsNoTouching" class="carousel slide" data-bs-touch="false">
                        <div class="carousel-inner">
                             <?php
        $count = 0;
        foreach ($products as $item) {
            if ($count == 6) {
                break; // stop loop after 6 items
            }
            if ($count % 3 == 0) {
                if ($count == 0) {
                    echo '<div class="carousel-item active">';
                } else {
                    echo '<div class="carousel-item">';
                }
                echo '<div class="row">';
            }
            if($count % 3 == 0){
            echo '<div class="col">'; }
            elseif($count % 3 == 1){
            echo '<div class="col d-none d-sm-block d-lg-block">';}
            else{
            echo '<div class="col d-none d-sm-none d-lg-block">'; }
            echo '<a href="productDetails.php?myid=' . $item["ProductID"] . '">
                      <div class="card border-0">
                     
                          <img class="feature-img" src="'.$item["productImgPath"].'" alt="more about ' . $item["productName"] . '">
                      </div>
                      </a>
                  </div>';
            $count++;
            if ($count % 3 == 0) {
                echo '</div></div>';
            }
        }
        if ($count % 3 != 0) {
            echo '</div></div>';
        }
        ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControlsNoTouching" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </section>

            <section>
                <div class="container">
                    <h2>Shop by Category</h2>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="featured-cat">
                                <div class="card border-0">
                                    <div class="cat-img">
                                        <a class="cat-title" href="products.php?categoryID=1">
                                        <img class="card-img-top" src="img/product/product-1.jpg" alt="Card image category top">
                                        </a>
                                    </div>
                                    <div class="card-body">
                                        <a class="cat-title" href="products.php?categoryID=1">Shop the latest Top <i class="fa-solid fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="featured-cat">
                                <div class="card border-0">
                                    <div class="cat-img">
                                        <a class="cat-title" href="products.php?categoryID=2">
                                        <img class="card-img-top" src="img/product/product-4.jpg" alt="Card image category bottom">
                                        </a>
                                    </div>
                                    <div class="card-body">
                                        <a class="cat-title" href="products.php?categoryID=2">Shop the latest Bottom <i class="fa-solid fa-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="winter">
                <div class="container">
                    <h2 id="headline">Countdown to winter collection</h2>
                    <div id="countdown">
                        <ul>
                            <li><span id="days"></span>days</li>
                            <li><span id="hours"></span>Hours</li>
                            <li><span id="minutes"></span>Minutes</li>
                            <li><span id="seconds"></span>Seconds</li>
                        </ul>
                    </div>
                </div>
            </section>
    



        <?php
        include "new_includes/footer.inc.php"
        ?>
        
        <script src="js/timer.js"></script>
        </main>
    </body>

</html>