<?php 
    session_start ();
    authenticateUser();
    
    //Helper function to authenticate the login.
    function authenticateUser()
    {
        global $adminname, $adminpassword, $errorMsg, $success;
        $success=true;
        if (empty($_POST["adminname"])) {
            $errorMsg .= "Username is required.<br>";
        } 
        else {
            $adminname = sanitize_input($_POST["adminname"]);  
        }
        if (empty($_POST["adminpassword"])) {
            $errorMsg .= "Password is required.<br>";
        }
        else {  
            $adminpassword = sanitize_input($_POST["adminpassword"]);  
        } 
        // Create database connection.
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);
        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else{
            // Prepare the statement:
            $stmt = $conn->prepare("SELECT * FROM Admin WHERE
            adminname=?");
            // Bind & execute the query statement:
            $stmt->bind_param("s", $adminname);
            $stmt->execute();
            $result = $stmt->get_result();
                if ($result->num_rows > 0){
                    $row = $result->fetch_assoc();
                    $AdminID = $row["AdminID"];
                    $adminname = $row["adminname"];
                    $password_hashed = $row["adminpassword"];
                // Check if the password matches:
                    if (!hash_equals($password_hashed, 
                            crypt($_POST["adminpassword"], $password_hashed))){
                        // Don't be too specific with the error message - hackers don't
                        // need to know which one they got right or wrong. :)
                        $errorMsg = "User not found or password doesn't match...";
                        $success = false;
                    }
                }
                else{
                    $errorMsg = "User not found or password doesn't match...";
                    $success = false;
                    }
            $stmt->close();
            }
        $conn->close();
        
        //to be displayed
            if ($success == false){
                $_SESSION["login_failed"] = true;
                header('Location: admin_login.php');
                exit; 
            }
            else{
                $_SESSION["AdminID"] = $AdminID; // Replace with actual admin ID retrieved from database
                $_SESSION["admin_login"] = true;
                header("location:adminpage.php");
                exit();
            }
    }
    //Helper function that checks input for amalicious or unwanted content.
    function sanitize_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    } 
    ?>