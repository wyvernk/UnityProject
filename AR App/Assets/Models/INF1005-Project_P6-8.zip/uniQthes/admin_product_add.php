<?php
  session_start();

  // Check if user is logged in as an admin
  if (!isset($_SESSION["AdminID"]) || $_SESSION["admin_login"] !== true) {
    header("Location: admin_login.php");
    exit();
  }

  // Create database connection.
  $config = parse_ini_file('../../private/db-config.ini');
  $conn = new mysqli($config['servername'], $config['username'],
  $config['password'], $config['dbname']);

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Handle form submission
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input values
    $ProductID = filter_var($_POST["ProductID"], FILTER_SANITIZE_NUMBER_INT);  
    $CategoryID = filter_var($_POST["CategoryID"], FILTER_SANITIZE_NUMBER_INT);
    $productName = filter_var($_POST["productName"], FILTER_SANITIZE_STRING);
    $price = filter_var($_POST["price"], FILTER_SANITIZE_NUMBER_FLOAT, 
            FILTER_FLAG_ALLOW_FRACTION);
    $size = filter_var($_POST["size"], FILTER_SANITIZE_STRING);
    $stock = filter_var($_POST["stock"], FILTER_SANITIZE_NUMBER_INT);
    $productImgPath = isset($_POST["productImgPath"]) ? filter_var
            ($_POST["productImgPath"], FILTER_SANITIZE_STRING) : null;
    $productDesc = filter_var($_POST["productDesc"], FILTER_SANITIZE_STRING);
    $rating = filter_var($_POST["rating"], FILTER_SANITIZE_NUMBER_INT);

    // Update product data in database
     $stmt = $conn->prepare("INSERT INTO Product (ProductID, CategoryID, "
             . "productName, price, size, stock, productImgPath, productDesc,"
             . " rating) " . "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
     $stmt->bind_param("iisdsissi", $ProductID, $CategoryID, $productName,
             $price, $size, $stock, $productImgPath, $productDesc, $rating);
     $stmt->execute();
     
    if ($stmt->affected_rows > 0) {
      echo "Product updated successfully";
       echo '<script>window.close();</script>';
      exit();
    } else {
      echo "Error updating product: " . $conn->error;
    }
  }
?>

<head>
  <title>Add Product</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="js/openForm.js"></script>
</head>

<body>

  <div class="container">
    <h2>Add Product</h2>
    <form method="post">
      <div class="form-group">
        <label for="ProductID">Product ID:</label>
        <input type="int" class="form-control" id="ProductID" name="ProductID" required>
      </div>  
      <div class="form-group">
        <label for="CategoryID">Category ID:</label>
        <input type="int" class="form-control" id="CategoryID" name="CategoryID" required>
      </div>

      <div class="form-group">
          <label for="productName">Product Name:</label>
          <input type="text" class="form-control" id="productName" name="productName" required>
      </div>    
      <div class="form-group">
          <label for="price">Price:</label>
          <input type="number" class="form-control" id="price" name="price" required>
      </div>
     <div class="form-group">
          <label for="size">Size:</label>
          <select id="size" name="size">
            <option value="small">Small</option>
            <option value="med">Medium</option>
            <option value="large">Large</option>
          </select>
        </div>

      <div class="form-group">
          <label for="stock">Stock:</label>
          <input type="int" class="form-control" id="stock" name="stock">
      </div>   
      <div class="form-group">
          <label for="productImgPath">Product Image:</label>
          <div class="input-group">
            <input type="text" class="form-control" id="productImgPath" name="productImgPath">
            <div class="input-group-append">
              <button type="button" class="btn btn-outline-secondary" id="selectImageBtn">Select Image</button>
            </div>
          </div>
        </div>
      <div class="form-group">
          <label for="productDesc">Product Description:</label>
          <input type="text" class="form-control" id="productDesc" name="productDesc" required>
      </div>      
      <div class="form-group">
        <label for="rating">Rating:</label>
        <input type="int" class="form-control" id="rating" name="rating">
      </div>

      <button type="submit" class="btn btn-primary">Add</button>
      <button type="button" class="btn btn-secondary" onclick="window.close()">Go Back</button>

    </form>
  </div>

</body>
</html>

<?php
  $conn->close();
?>