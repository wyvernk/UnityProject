<?php
    session_start();

    if (isset($_POST["quantity"])) {

        // Open connection
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);
        
        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else 
        {
            // Prepare statement to retrieve stock
            $stmt = $conn->prepare("SELECT * FROM Product WHERE ProductID=? AND size=?");

            foreach ($_SESSION["cart"] as $key => $item) {  
                echo $item["product_id"] . " " . $item["product_size"] . "<br>";
                if ($item["product_id"] == $_POST["product_id"] && $item["product_size"] == $_POST["product_size"]) {

                    // Translate size first
                    if($item["product_size"] == "S") {
                        $size = "small";
                    }
                    else if($item["product_size"] == "M") {
                        $size = "med";
                    }
                    else {
                        $size = "large";
                    }

                    // Bind and execute SQL statement
                    $stmt->bind_param("is", $item["product_id"], $size);    
                    $stmt->execute();

                    $result = $stmt->get_result();           
                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $stock = $row["stock"];

                            // Check if stock is more than GET quantity + SESSION cart quantity
                            if ($stock >= $_POST["quantity"]) {
                                // Updated quantity
                                $_SESSION["cart"][$key]["quantity"] = $_POST["quantity"];  
                            }
                            else {
                                $_SESSION["message"] = "Not enough stock";  
                            }
                        }
        
                    break;
                }
            }  
            $stmt->close();
        }
        $conn->close();
    }
    else  {
        header("location:index.php");
    }

    header("location:shopping-cart.php");
?>
