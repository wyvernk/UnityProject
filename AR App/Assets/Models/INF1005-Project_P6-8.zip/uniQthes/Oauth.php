<?php
    session_start();
    // Function to check if an email has already been taken
    function checkEmailExists($email, $name) {
        global $errorMsg, $success;
        $success = true;

        // Create database connection.
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);
        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            // $success = true;
        }
        else
        {
            // Check for duplicate email
            // Prepare the statement:
            $stmt = $conn->prepare("SELECT * FROM User WHERE
            email=?");

            // Bind & execute the query statement:
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            // Check if Email exists, retrieve information
            if ($result->num_rows > 0) 
            {
                $row = $result->fetch_assoc();
                if ($row["google"] == 0) // if it is not google account
                {
                    $errorMsg = "Email already exists";
                    $_SESSION["loginErr"] = $errorMsg;
                    $success = false;
                }
                else
                {
                    $_SESSION['user_id'] = $row["UserID"];
                    $_SESSION['email'] = $row["email"];
                    $_SESSION['fname'] = $row["fName"];
                    $_SESSION['lname'] = $row["lName"];
                    $_SESSION['address'] = $row["address"];
                    $_SESSION['phonenumber'] = $row["phone"];
                }

                $stmt->close();
            }
            else 
            {
                $stmt->close();
                // Insert into DB
                // Prepare the statement:
                $stmt = $conn->prepare("INSERT INTO User (email, lName, google) VALUES (?, ?, ?)");

                // Bind & execute the query statement:
                $google = 1;
                $stmt->bind_param("ssi", $email, $name, $google);

                if (!$stmt->execute())
                {
                    $errorMsg = "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
                    $success = false;
                }
                $stmt->close();
                
                // Prepare the statement to get lates UserID
                $stmt = $conn->prepare("SELECT * from User WHERE UserID = (SELECT MAX(UserID) FROM User)");

                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $_SESSION["user_id"] = $row["UserID"];
                    $_SESSION["email"] = $row["email"];
                    $_SESSION["lname"] = $row["lName"];
                }

                $stmt->close();

            }
        }
        $conn->close();
    }

    // authenticate code from Google OAuth Flow 
    if (isset($_GET['code'])) {
        $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
        $client->setAccessToken($token['access_token']);
    
        // set access token in session
        $_SESSION['access_token'] = $token['access_token'];
        
        // get profile info 
        $google_oauth = new Google_Service_Oauth2($client);
        $google_account_info = $google_oauth->userinfo->get();
        $email =  $google_account_info->email;
        $name =  $google_account_info->name;

        checkEmailExists($email, $name);

        if (!$success) {
            // revoke the access token
            $client->revokeToken($_SESSION['access_token']);

            // unset session variables
            unset($_SESSION['access_token']);
            header("location:login.php?err=1");
            exit();
        }
    
        // store email and name in session variables
        $_SESSION['login'] = "1";
        $_SESSION['google'] = "1";
        
        // redirect to index page
        header('Location: profile.php');
        exit();
    }
?>