<!DOCTYPE html>

<html lang="en">
    
<?php
    // Start session
    session_start();

    // INITIALISE VARIABLES
    $formErr = $fnameErr = $lnameErr = $addressErr = $phoneErr = $errorMsg = "";
    $userID = $_SESSION["user_id"];

    $success = true;

    // VALIDATE FORM FUNCTION
    function editFormValidated() {
        global $fnameErr, $lnameErr, $addressErr, $phoneErr;
        global $fname, $lname, $address, $phone;
        $validated = true; // local variable

   
        // Validate Last name
        if (empty($_POST["lname"])) {
            $lnameErr .= "*Last Name is required.<br>";
            $validated = false;
        } else {
            $lname = sanitize_input($_POST["lname"]);
            // Check length of Last Name
            if (strlen($lname) > 45) {
                $lnameErr .= "*Last name too long! Maximum 45 characters only.";
                $validated = false;
            }
        }

        // Validate First name
        $fname = sanitize_input($_POST["fname"]);
        // Check length of First Name
        if (strlen($fname) > 45) {
            $fnameErr .= "*First name too long! Maximum 45 characters only.";
            $validated = false;
        }

        // Validate Address
        if (!empty($_POST["address"])) {
            // sanitise address if exists
            $address = sanitize_input($_POST["address"]);
          }
          
        // Validate phone
        if (!empty($_POST["phone"])) {
            // sanitise phone if exists
            $phone = sanitize_input($_POST["phone"]);
            
            // Check phone number length
            if (strlen($phone) !== 8) {
            $phoneErr .= "*Invalid phone number";
            $validated = false;
            }
        }

        return $validated;
    }

    // Helper function that checks input for malicious or unwanted content.
    function sanitize_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    // Update Account
    function updateAccount() {
        global $userID, $fname, $lname, $address, $phone, $success;
        // Create database connection.
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);
        
        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else
        {
            // Insert new user to database
            // Prepare the statement:
            $stmt = $conn->prepare("UPDATE User SET fName=?, lName=?, address=?, phone=? WHERE UserID=?");

            // Bind & execute the query statement:
            $stmt->bind_param("ssssi", $fname ,$lname, $address, $phone, $userID);

            if (!$stmt->execute())
            {
                $errorMsg = "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
                $success = false;
            }
            $stmt->close();
        }
        $conn->close();
    }

?>


<main class="container">
    <?php
    echo $errorMsg;

    if (editFormValidated()) {
        updateAccount();
        $_SESSION["fname"] = $fname;
        $_SESSION["lname"] = $lname;
        $_SESSION["address"] = $address;
        $_SESSION["phonenumber"] = $phone;


        header("location:profile.php");
    } 
    else {
        $formErr = "Please fix the errors below:";

        // Populate form with edited values
        $_SESSION["edited"] = true;
        $_SESSION["edit_lname"] = $_POST["lname"];
        $_SESSION["edit_fname"] = $_POST["fname"];
        $_SESSION["edit_address"] = $_POST["address"];
        $_SESSION["edit_phonenumber"] = $_POST["phone"];

        // Pass error messages to register page through session
        $_SESSION["formErr"] = $formErr;
        $_SESSION["lnameErr"] = $lnameErr;
        $_SESSION["fnameErr"] = $fnameErr;
        $_SESSION["addressErr"] = $addressErr;
        $_SESSION["phoneErr"] = $phoneErr;

        header("location:edit_account.php");

    }

    ?>

</main>



</html>