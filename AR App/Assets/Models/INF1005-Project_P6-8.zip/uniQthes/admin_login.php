<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Admin Login</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="new_css/style.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
        <script defer src="js/validation.js"></script>
    </head>

    <body id="adminlogin-body">
        <main>
        <div class="card adminlogin">
            <div class="card-header">
                <h1 class="text-center">Admin Login</h1>
            </div>
            <div class="card-body">
                <?php if (isset($_SESSION['login_failed'])): ?>
                <p class="text-danger text-center">Username or password is wrong. <a href="mailto:2202855@sit.singaporetech.edu.sg">Contact administrator</a> if you need help.</p>
                <?php
                    unset($_SESSION['login_failed']);
                    endif; ?>
                <form action="admin_processlogin.php" method="post">
                    <div class="form-group">
                        <label for="adminname">Username</label>
                        <input type="text" class="form-control" id="adminname" name="adminname" maxlength="45" data-validation-required-message="Please enter username" required>
                        <div class="invalid-feedback"></div>
                    </div>
                    <div class="form-group">
                        <label for="adminpassword">Password</label>
                        <input type="password" class="form-control" id="adminpassword" name="adminpassword" data-validation-required-message="Please enter password" maxlength="45" required>
                        <div class="invalid-feedback"></div>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-block btn-login">Login</button>
                    </div>
                </form>
            </div>
        </div>
       </main>
    </body>
    <?php 
        if(!isset($_SESSION["admin_login"])) {
            session_unset();
            session_destroy();
        }
    ?>
</html>
