<!DOCTYPE html>

<?php
if (!isset($_POST["address"])) {
    header("location:index.php");
    exit();
}

$address = $email = $notes = $fname = $lname = $phonenumber = $cardnumber = $cvv = $expriration = $errorMsg = "";
$formErr = $addressErr = $phonenumberErr = $emailErr = $fnameErr = $lnameErr = $cardErr = $cvvErr = $expErr = $order_id= "";
$success = true;

$date = date("Y-m-d");
$status = "Pending";

//check address
if (empty($_POST["address"]))
{
    $addressErr .= "Address is required.<br>";
    $success = false;
}
else
{  
   //sanitise address
  $address =  sanitize_input($_POST["address"]);
}

//check phonenumber
if (empty($_POST["phonenumber"]))
{
    $phonenumberErr .= "Phone number is required.<br>";
    $success = false;
}

else
{
    //sanitize phonenumber
    $phonenumber = sanitize_input($_POST["phonenumber"]);
    // Additional check to make sure e-mail address is well-formed.
    if (strlen($phonenumber) !== 8)
    {
        $phonenumberErr .= "Invalid phone number.<br>";
        $success = false;
    }
}

//check email
if (empty($_POST["email"]))
{
    $emailErr .= "Email is required.<br>";
    $success = false;
}
else
{
    //sanitize email
    $email = sanitize_input($_POST["email"]);
    // Additional check to make sure e-mail address is well-formed.
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))
    {
        $emailErr .= "Invalid email format.<br>";
        $success = false;
    }
}

//check notes
if (!empty($_POST["notes"]))
{
    //sanitize notes
     $notes =  sanitize_input($_POST["notes"]);
}

//check first name
if (empty($_POST["fname"]))
{
    $fnameErr .= "First name is required.<br>";
    $success = false;
}
else
{
    //sanitize first name
    $fname = sanitize_input($_POST["fname"]);
}

//check last name
if (empty($_POST["lname"]))
{
    $lnameErr .= "Last name is required.<br>";
    $success = false;
}
else
{
        //sanitize last name
    $lname = sanitize_input($_POST["lname"]);
}

//check card number
if (empty($_POST["card_number"]))
{
    $cardErr .= "Card number is required.<br>";
    $success = false;
}
else
{
    //sanitize card number
    $cardNo = sanitize_input($_POST["card_number"]);
}

//check cvv
if (empty($_POST["cvv"]))
{
    $cvvErr .= "CVV is required.<br>";
    $success = false;
}
else
{
    $cardCvv = sanitize_input($_POST["cvv"]);
}

//check expiration
if (empty($_POST["expiration"]))
{
    $expErr .= "Expiration date is required.<br>";
    $success = false;
}
else
{       
    $cardExp = sanitize_input($_POST["expiration"]);
     if($_POST["expiration"] < date('Y-m'))
     {  
         $expErr .= "Card expired.<br>";
         $success = false;
     }
}

 //Helper function that checks input for malicious or unwanted content.
function sanitize_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}


function confirmOrder() {
    global $errorMsg, $date, $status, $address, $notes, $fname, $lname, $phonenumber, $email, $order_id;
    // Create database connection.
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);
    
    // Check connection
    if ($conn->connect_error)
    {
        $errorMsg = "Connection failed: " . $conn->connect_error;
        $success = false;
    }
    else
    {
        // Prepare the statement to inset into Orders:
        $orders_stmt = $conn->prepare("INSERT INTO Orders (CustomerID, orderDate,
        orderStatus, deliveryAddress, orderNotes, customerEmail, customerName, customerPhone) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        
        $name = $fname . ' ' . $lname;
        
        // Bind & execute the query statement:
        $orders_stmt->bind_param("issssssi", $_SESSION["user_id"], $date, $status, $address, $notes, $email, $name, $phonenumber);

        if (!$orders_stmt->execute())
        {
            $errorMsg = "Execute failed: (" . $orders_stmt->errno . ") " . $orders_stmt->error;
            $success = false;
        }
        else
        {
            $order_id = $conn->insert_id;
        }
        $orders_stmt->close();

        // Prepare the statement to insert into OrderList:
        $orderlist_stmt = $conn->prepare("INSERT INTO OrderList (OrderID, productName, quantity, size, price) VALUES (?, ?, ?, ?, ?)");

        $cart_checkout = $_SESSION["cart"];
        foreach ($cart_checkout as $item) {

            // Bind & execute the query statement:
            $orderlist_stmt->bind_param("isssd", $order_id, $item["product_name"], $item["quantity"], $item["product_size"], $item["product_price"]);

            if (!$orderlist_stmt->execute())
            {
                $errorMsg = "Execute failed: (" . $orderlist_stmt->errno . ") " . $orderlist_stmt->error;
                $success = false;
            }

        }
        $orderlist_stmt->close();

        // Update Product Stock
        $get_stock_stmt = $conn->prepare("SELECT * FROM Product WHERE ProductID=? AND size=?");
        $update_stock_stmt = $conn->prepare("UPDATE Product SET stock=? WHERE ProductID=? AND size=?");

        foreach ($cart_checkout as $item) {

            // Check Size
            if ($item["product_size"] == "S") {
                $size = "small";
            }
            else if ($item["product_size"] == "M") {
                $size = "med";
            }
            else {
                $size = "large";
            }
        
            $get_stock_stmt->bind_param("is", $item["product_id"], $size);
        
            if (!$get_stock_stmt->execute())
            {
                $errorMsg = "Execute failed: (" . $orderlist_stmt->errno . ") " . $orderlist_stmt->error;
                $success = false;
            }
            $result = $get_stock_stmt->get_result();
        
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $stock = $row["stock"];
                
                // Remove ordered quantity from stock
                $stock -= $item["quantity"];
        
                $update_stock_stmt->bind_param("iis", $stock, $item["product_id"], $size);
                if (!$update_stock_stmt->execute())
                {
                    $errorMsg = "Execute failed: (" . $update_stock_stmt->errno . ") " . $update_stock_stmt->error;
                    $success = false;
                }
        
            }
        
        }
        
        $get_stock_stmt->close();
        $update_stock_stmt->close();
        
    }
    $conn->close();
}

function PrintOrderConfirmation()
{
    global $order_id;
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
    $config['password'], $config['dbname']);
    
    $stmt = $conn->prepare("SELECT * FROM Orders WHERE OrderID=?");
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    
    if($result->num_rows > 0)
    {      
        $row = $result->fetch_assoc();
        echo     '<div class="card_item">';
        echo     '<div class="row">';
            echo     '<div class="col-lg-12">';
            echo     "<h2>Order ID: #". $row["OrderID"] . "</h2>";
            echo     "</div>";
        echo     "</div>";
        echo     '<div class="row">';
            echo     '<div class="col-lg-4">';       
            echo     "<h3>Details: </h3>";
             echo    "<p>Email: ". $row["customerEmail"] ."</p>";
            echo     "<p>Phone Number: ". $row["customerPhone"] ."</p>";
            echo     "<p>Address: ". $row["deliveryAddress"] ."</p>";
            echo     "<p>Order Date: ". $row["orderDate"] ."</p>";
        echo     "</div>";
        
        echo     '<div class="col-lg-4">';
            echo     "<h3>Order: <span>Price:</span></h3>"; 
            

        $stmt = $conn->prepare("SELECT * FROM OrderList WHERE OrderList.OrderID =?");
        $stmt->bind_param("i", $order_id);
        $stmt->execute();
        $orderresult = $stmt->get_result();
        
            $pricetotal = 0;
            while($row2 = $orderresult->fetch_assoc())
            {
                echo "<p>" . $row2["productName"] . "(". $row2["size"] . ") x" . $row2["quantity"] . "<span>$" . $row2["price"] . "</span></p>";  
                $pricetotal += $row2["price"] * $row2["quantity"];
            }
              echo "<br>";
              $pricetotal = number_format((float)$pricetotal, 2, '.', '');
            echo     "<p>Total: <span>$" .$pricetotal . "</span></p>";         
        echo "</div>";
            
            echo     '<div class="col-lg-4">';            
                echo     "<h3>Status: " . $row["orderStatus"] . "</h3>";                     
            echo     "</div>";
        echo "</div>";
        
        echo  '<div class="row">';
            echo   '<div class="col-lg-12">';
            echo   '<div class="center_text">';
            echo   "<p>Notes: ". $row["orderNotes"] ."</p>";
        echo "</div>";
        echo "</div>";
        echo "</div>";
        echo "</div>";     
         
        echo "<hr>";
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">

<?php 
    include "new_includes/head.inc.php"
?>

    <link rel="stylesheet" href="css/process_payment.css">
            <!-- Custom JS -->
        <script defer src="js/process_payment.js"></script>
        
<main>
<body>
    
<?php 
    include "new_includes/nav.inc.php"
?>
    
<!--Results of form submission-->
 <div class="container">
            <div class="row">
<?php
        if ($success)
        {
            confirmOrder();
            unset($_SESSION["cart"]);
            unset($_SESSION["cart_count"]);
            //header("Refresh:0");

            //echo "DB error message: " . $errorMsg;
            echo '<div class="section-title">';
            echo "<h1>Thank you for your purchase " .$fname. " " . $lname . "!</h1><br>";
            echo '</div>';
            PrintOrderConfirmation();
            
            echo '<div class="center_text">';
            echo '<a href="index.php"><button class="site-btn">Home</button></a>';
            echo '</div>';
           
        }
        
        else
        {
            echo '<div class="section-title">';
            echo "<h1>Oh No!</h1>";
            echo "<h2>The following input errors were detected:</h2>";
            echo "<p>" . $errorMsg . "</p>";
            echo "<p>Please try again!</p>";
            echo '<a href="checkout.php"><button class="site-btn">Back</button></a>';
            echo '</div>';

            $formErr = "Please fix the errors below:";

            // To repopulate form if got errors
            if(!isset($_SESSION["login"])) {
                $_SESSION["address"] = $address;
                $_SESSION["phonenumber"] = $phonenumber;
                $_SESSION["email"] = $email;
                $_SESSION["fname"] = $fname;
                $_SESSION["lname"] = $lname;
                $_SESSION["cardNo"] = $cardNo;
                $_SESSION["cardCvv"] = $cardCvv;
                $_SESSION["cardExp"] = $cardExp;
            }

            // Pass error messages to register page through session
            $_SESSION["formErr"] = $formErr;
            $_SESSION["addressErr"] = $addressErr;
            $_SESSION["phonenumberErr"] = $phonenumberErr;
            $_SESSION["emailErr"] = $emailErr;
            $_SESSION["fnameErr"] = $fnameErr;
            $_SESSION["lnameErr"] = $lnameErr;
            $_SESSION["cardErr"] = $cardErr;
            $_SESSION["cvvErr"] = $cvvErr;
            $_SESSION["expErr"] = $expErr;
            
            header("location:checkout.php");

        }
?>
        </div>
</div>

<br>

 <?php 
        include "new_includes/footer.inc.php";
    ?>
</div>
</main>
</body>

</html>
