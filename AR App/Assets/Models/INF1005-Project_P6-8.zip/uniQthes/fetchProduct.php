<?php

function fetchData() {

    global $ProductID, $productName, $categoryID, $price, $size, $stock, $productImgPath, $productDesc, $Rating, $errorMsg, $success
    , $products, $minPirce, $maxPrice, $priceOrder,$num_rows,$search;
    // Retrieve the categoryID parameter from the URL
    if (isset($_GET['categoryID'])) {
        $categoryID = $_GET['categoryID'];
    } elseif (isset($_GET['priceRange'])) {
        $price = $_GET['priceRange'];
        $priceArr = explode("-", $price);
        $minPrice = $priceArr[0];
        $maxPrice = $priceArr[1];
    } elseif(isset($_POST['search'])){
        $search = sanitize_input($_POST['search']);
    }
    else {
        $price = null;
        $categoryID = null;  
        $priceOrder=null;
        $search=null;
    }
    // Create database connection.
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
            $config['password'], $config['dbname']);
// Check connection
    if ($conn->connect_error) {
        echo "Connection failed: " . $conn->connect_error;
        $errorMsg = $success = false;
    } else {
        if ($categoryID) {
            $stmt = $conn->prepare("SELECT distinct ProductID ,productName, categoryID, price, productImgPath,rating FROM UniQthes.Product WHERE categoryID = ?");
            $stmt->bind_param("i", $categoryID);
        } elseif ($price) {
            $stmt = $conn->prepare("SELECT distinct ProductID ,productName, categoryID, price, productImgPath,rating FROM UniQthes.Product
            WHERE price BETWEEN ? AND ?");

         $stmt->bind_param("dd", $minPrice, $maxPrice);
        }elseif($priceOrder){
            $stmt = $conn->prepare("SELECT distinct ProductID ,productName, categoryID, price, productImgPath,rating FROM UniQthes.Product ORDER BY price ?" );
            $stmt->bind_param("s", $priceOrder);
        }
        elseif($search){
            $stmt = $conn->prepare("SELECT distinct ProductID ,productName, categoryID, price, productImgPath,rating FROM UniQthes.Product where productDesc like CONCAT( '%',?,'%') OR productName like CONCAT( '%',?,'%')" );
            $stmt->bind_param("ss", $search,$search);
        }
        else {
            $stmt = $conn->prepare("SELECT distinct ProductID ,productName, categoryID, price, productImgPath,rating FROM UniQthes.Product;");
        }
        // Bind & execute the query statement:
        $stmt->execute();
        $result = $stmt->get_result();
        $products = array(); // Create an empty array to hold the products
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
            $success = true;
        } else {
            //echo "no data";
            $errorMsg = "data not found";
            $success = false;
        }
        json_encode($products);
        $stmt->close();
    }
    $conn->close();
}

fetchData();

function sanitize_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
?>
