<?php

function fetchData() {

    global $ProductID, $productName, $categoryID, $price, $size, $stock, $productImgPath,
    $productDesc, $Rating, $errorMsg, $success, $imgId, $stock_L, $stock_M, $stock_S;

    if (isset($_GET["myid"])) {
        $ProductID = $_GET["myid"];
    } else {
        $ProductID = null;
    }
    // Create database connection.
    $config = parse_ini_file('../../private/db-config.ini');
    $conn = new mysqli($config['servername'], $config['username'],
            $config['password'], $config['dbname']);
// Check connection
    if ($conn->connect_error) {
        echo "Connection failed: " . $conn->connect_error;
        $errorMsg = $success = false;
    } else {
        
        $stmt = $conn->prepare("SELECT * FROM UniQthes.Product where ProductID =?;");
        $stmt->bind_param("i", $ProductID);
        $stmt->execute();
        $result = $stmt->get_result();
        
        //Get S stock
        $stmt_size = $conn->prepare("SELECT stock FROM UniQthes.Product where ProductID =? AND size=?;");
        $s = 'small';
        $stmt_size->bind_param("is", $ProductID,$s);
        $stmt_size->execute();
        $result_S = $stmt_size->get_result();   
        
        
        //Get M stock
        
        $m = 'med';
        $stmt_size->bind_param("is", $ProductID,$m);
        $stmt_size->execute();  
        $result_M = $stmt_size->get_result();
        
         //Get L stock
        
        $l= 'large';
        $stmt_size->bind_param("is", $ProductID,$l);
        $stmt_size->execute();  
        $result_L = $stmt_size->get_result();
        
        
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $ProductID = $row["ProductID"];
            $categoryID = $row["categoryID"];
            $productName = $row["productName"];
            $price = $row["price"];
            $productImgPath = $row["productImgPath"];
            $productDesc = $row["productDesc"];
            $Rating = $row["rating"];
            $success = true;
        } else {
            header("Location:index.php");
            $errorMsg = "data not found";
            $success = false;
        }
        if ($result_S->num_rows > 0) {
            $row_S = $result_S->fetch_assoc();
            $stock_S = $row_S['stock'];
        } else {
            $stock_S = 0;
        }

        if ($result_M->num_rows > 0) {
            $row_M = $result_M->fetch_assoc();
            $stock_M = $row_M['stock'];
        } else {
            $stock_M = 0;
        }

        if ($result_L->num_rows >0 ) {
            $row_L = $result_L->fetch_assoc();
            $stock_L = $row_L['stock'];
        } else {
            $stock_L = 0;
        }
        $stmt->close();
        $stmt_size->close();
    }
    $conn->close();
}

fetchData();

?>
