<?php
    if (!isset($_POST["empty_cart"])) {
        header("location:index.php");
    }
    else {
        session_start();
        unset($_SESSION["cart"]);
        unset($_SESSION["cart_count"]);
        header("location:shopping-cart.php");
    }
?>