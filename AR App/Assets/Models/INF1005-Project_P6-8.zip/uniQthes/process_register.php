<!DOCTYPE html>

<html lang="en">
    
<?php
    // Start session
    session_start();

    if (!isset($_POST["email"])) {
        header("location:index.php");
        exit();
    }

    // INITIALISE VARIABLES
    $formErr = $fnameErr = $lnameErr = $emailErr = $pwdErr = $pwdConfirmErr = $phonenumberErr = $token = $dbErr = "";

    $email = $lname = $errorMsg = $address = $phonenumber = "";
    $status = "Pending";
    $token = md5(rand());

    $success = true;

    // VALIDATE FORM FUNCTION
    function registerFormValidated() {
        global $fnameErr, $lnameErr, $emailErr, $pwdErr, $pwdConfirmErr, $dbErr, $phonenumberErr;
        global $fname, $lname, $email, $pwd, $address, $phonenumber,  $pwd_hashed, $pwd_confirm;
        $validated = true; // local variable

        // Validate email
        if (empty($_POST["email"])) {
            $emailErr .= "*Email is required.<br>";
            $validated = false;
        } else {
            $email = sanitize_input($_POST["email"]);
            // Additional check to make sure e-mail address is well-formed.
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $emailErr .= "*Invalid email format.<br>";
                $validated = false;
            }
        }


        // Validate Last name
        if (empty($_POST["lname"])) {
            $lnameErr .= "*Last Name is required.<br>";
            $validated = false;
        } else {
            $lname = sanitize_input($_POST["lname"]);
            // Check length of Last Name
            if (strlen($lname) > 45) {
                $lnameErr .= "*Last name too long! Maximum 45 characters only.";
                $validated = false;
            }
        }

        // Validate First name
        $fname = sanitize_input($_POST["fname"]);
        // Check length of First Name
        if (strlen($fname) > 45) {
            $fnameErr .= "*First name too long! Maximum 45 characters only.";
            $validated = false;
        }
        
        if (!empty($_POST["address"])) {
          // sanitise address if exists
          $address = sanitize_input($_POST["address"]);
        }
        
        if (!empty($_POST["phonenumber"])) {
          // sanitise phonenumber if exists
          $phonenumber = sanitize_input($_POST["phonenumber"]);
          
           if (strlen($phonenumber) !== 8) {
            $phonenumberErr .= "*Invalid phone number";
            $validated = false;
            }
        }
        

        // Validate Password
        if (empty($_POST["pwd"])) {
            $pwdErr .= "*Password is required.<br>";
            $validated = false;
        } else {
            $pwd = $_POST["pwd"];
            // Validate password strength
            $uppercase    = preg_match('@[A-Z]@', $pwd);
            $lowercase    = preg_match('@[a-z]@', $pwd);
            $number       = preg_match('@[0-9]@', $pwd);
            $specialchars = preg_match('@[^\w]@', $pwd);

            if (!$uppercase || !$lowercase || !$number || !$specialchars || strlen($pwd) < 8) {
                $pwdErr .= "*Password does not contain:<br>";
                if (!$uppercase) {
                    $pwdErr .= "-uppercase letters<br>";
                }
                if (!$lowercase) {
                    $pwdErr .= "-lowercase letters<br>";
                }
                if (!$number) {
                    $pwdErr .= "-numbers<br>";
                }
                if (!$specialchars) {
                    $pwdErr .= "-special characters<br>";
                }
                if (strlen($pwd) < 8) {
                    $pwdErr .= "-at least 8 characters long<br>";
                }
                $validated = false;
            }
            
        }

        // Validate Confirm Password
        if (empty($_POST["pwd_confirm"])) {
            $pwdConfirmErr .= "*Confirm password required.<br>";
            $validated = false;
        } else if (!empty($_POST["pwd"])) {
            $pwd_confirm = $_POST["pwd_confirm"];

            // Check if passwords match
            if ($pwd_confirm !== $pwd) {
                $pwdConfirmErr .= "*Passwords do not match.<br>";
                $validated = false;
            }
            else {
                $pwd_hashed = password_hash($pwd, PASSWORD_DEFAULT);
                // store hash in database for validation later
            }
        }
        // if (!$success) {
        //     $formErr = "Please fix the errors below:";
        // }
        return $validated;
    }


    // Helper function that checks input for malicious or unwanted content.
    function sanitize_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    // Register new User into DB
    function registerUser() {
        global $fname, $lname, $email, $address,$phonenumber, $pwd_hashed, $status, $token, $errorMsg, $success;
        // Create database connection.
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);
        
        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            $success = false;
        }
        else
        {
            // Insert new user to database
            // Prepare the statement:
            $stmt = $conn->prepare("INSERT INTO User (fName, lName,
            email, password, phone, address, status, activation_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

            // Bind & execute the query statement:
            $stmt->bind_param("ssssssss", $fname, $lname, $email, $pwd_hashed, $phonenumber,$address, $status, $token);

            if (!$stmt->execute())
            {
                $errorMsg = "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
                $success = false;
            }
            $stmt->close();
        }
        $conn->close();
    }

    // Function to check if an email has already been taken
    function checkUserExists() {
        global $email, $errorMsg;
        $emailExists = false; // local variable

        // Create database connection.
        $config = parse_ini_file('../../private/db-config.ini');
        $conn = new mysqli($config['servername'], $config['username'],
        $config['password'], $config['dbname']);
        // Check connection
        if ($conn->connect_error)
        {
            $errorMsg = "Connection failed: " . $conn->connect_error;
            // $success = true;
        }
        else
        {
            // Check for duplicate email
            // Prepare the statement:
            $stmt = $conn->prepare("SELECT * FROM User WHERE
            email=?");

            // Bind & execute the query statement:
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $errorMsg = "Email taken";
                $emailExists = true;
            }
            $stmt->close();
        }
        $conn->close();

        return $emailExists;
    }

    function send_email_verify($fname, $lname, $token) {
        // send email verification
        
    }
?>


<main class="container">
    <?php

    if (registerFormValidated()) {
        if (checkUserExists()) {
            $formErr = "Email already exists";
            $_SESSION["formErr"] = $formErr;
            header("location:register.php");
        }
        else {
            registerUser();
            echo $errorMsg;
            send_email_verify("$fname", "$lname", "$token");

            $_SESSION["success"] = true;
            header("location:registration_success.php");
        }
    } 
    else {
        $formErr = "Please fix the errors below:";

        // To repopulate form if got errors
        $_SESSION["email"] = $email;
        $_SESSION["fname"] = $fname;
        $_SESSION["lname"] = $lname;
        $_SESSION["address"] = $address;
        $_SESSION["phonenumber"] = $phonenumber;

        // Pass error messages to register page through session
        $_SESSION["formErr"] = $formErr;
        $_SESSION["lnameErr"] = $lnameErr;
        $_SESSION["fnameErr"] = $fnameErr;
        $_SESSION["emailErr"] = $emailErr;
        $_SESSION["adressErr"] = $addressErr;
        $_SESSION["phonenumberErr"] = $phonenumberErr;
        $_SESSION["pwdErr"] = $pwdErr;
        $_SESSION["pwdConfirmErr"] = $pwdConfirmErr;    
        header("location:register.php");
    }

    ?>

</main>



</html>