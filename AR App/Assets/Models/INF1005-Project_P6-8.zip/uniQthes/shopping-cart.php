<!DOCTYPE html>
<html lang="en">

<?php 
    session_start();
    include "new_includes/head.inc.php"
?>
<?php
    if (isset($_SESSION["message"])) {
        echo '<script type="text/javascript">';
        echo 'jQuery(function($){alert("' . $_SESSION["message"] . '");});';
        echo '</script>';
        unset($_SESSION["message"]);
    }
?>

<body>
    <main>
    <?php 
        include "new_includes/nav.inc.php"
    ?>

    <div class="container">
        <h2>Shopping Cart</h2>

        <?php

            if (isset($_POST["checkout"])) {
                header("location:checkout.php");
            }

            if(empty($_SESSION["cart"])) {
                echo "<h3>Cart is Empty</h3>";
            }
            else {
                $cart_list = $_SESSION["cart"]; 
                $subtotal = 0;
        ?>

            <!-- Start of Dynamic Shopping Cart -->
            <div class="container">

                <div class="row">
                    <!-- Looped Cart List -->
                    <div class="col-lg-8 col-md-6">
                        <?php      
                            // Open connection
                            $config = parse_ini_file('../../private/db-config.ini');
                            $conn = new mysqli($config['servername'], $config['username'],
                            $config['password'], $config['dbname']);
                            
                            // Check connection
                            if ($conn->connect_error)
                            {
                                $errorMsg = "Connection failed: " . $conn->connect_error;
                                $success = false;
                            }
                            else {
                                // Prepare statement to retrieve stock
                                $stmt = $conn->prepare("SELECT * FROM Product WHERE ProductID=? AND size=?");

                                foreach ($cart_list as $item) { 

                                    // Translate size first
                                    if($item["product_size"] == "S") {
                                        $size = "small";
                                    }
                                    else if($item["product_size"] == "M") {
                                        $size = "med";
                                    }
                                    else {
                                        $size = "large";
                                    }

                                    // Retrieve stock from DB
                                    // Bind and execute SQL statement
                                    $stmt->bind_param("is", $item["product_id"], $size);    
                                    $stmt->execute();
                                    $result = $stmt->get_result(); 
                                    if ($result->num_rows > 0) {
                                        $row = $result->fetch_assoc();
                                        $stock = $row["stock"];
                                    }
        
                                    // Calculate Subtotal
                                    $price = $item['product_price'];
                                    $quantity = $item["quantity"];
                                    $item_total = $price * $quantity;   // calculate the total price of the item
                                    $subtotal += $item_total;          // add the item total to the running subtotal

                        ?>         
                        <!-- Start Looped Elements -->
                        <div class="row">
                            <div class="col-3">
                                <img class="cart-img" src="<?php echo $item['product_img']; ?>" alt="<?php echo $item['product_name']; ?>">
                            </div>
                            <div class="col-7">
                                <h2 class="product-title"><?php echo $item['product_name']; ?></h2>
                                <p>Product ID: <?php echo $item['product_id']; ?></p>
                                <p class="product-description"><?php echo $item['product_desc']; ?></p>
                                <p>Size: <?php echo $item['product_size']; ?>&emsp;Stock: <?php echo $stock ?></p>
                                <p class="product-price"><?php echo $item['product_price']; ?></p>

                                <!-- Quantity Dropdown -->
                                <form method="post" action="update_quantity.php">
                                    <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                    <input type="hidden" name="product_size" value="<?php echo $item['product_size']; ?>">

                                    <label>Quantity:</label>
                                    <div class="dropdown">
                                        <select class="form-select cart-quantity" name="quantity" aria-label="size selection" onchange="this.form.submit()">
                                            <option value="1" <?php echo ($item['quantity'] == 1) ? 'selected' : ''; ?>>1</option>
                                            <option value="2" <?php echo ($item['quantity'] == 2) ? 'selected' : ''; ?>>2</option>
                                            <option value="3" <?php echo ($item['quantity'] == 3) ? 'selected' : ''; ?>>3</option>
                                            <option value="4" <?php echo ($item['quantity'] == 4) ? 'selected' : ''; ?>>4</option>
                                            <option value="5" <?php echo ($item['quantity'] == 5) ? 'selected' : ''; ?>>5</option>
                                            <option value="6" <?php echo ($item['quantity'] == 6) ? 'selected' : ''; ?>>6</option>
                                        </select>
                                    </div>
                                </form>                  
                            </div>
                            <div class="col-2 cart-column">
                                <form action="remove_cart_item.php" method="post">
                                    <input type="hidden" name="product_id" value="<?php echo $item['product_id']; ?>">
                                    <input type="hidden" name="product_size" value="<?php echo $item['product_size']; ?>">
                                    
                                    <button class="cart-remove-btn" type="submit"><i class="fa fa-times" aria-hidden="true"></i></button>
                                </form>
                                <p class="item-subtotal">Subtotal: <?php echo $item['product_price'] * $item['quantity']; ?></p>
                            </div>
                        </div>
                        <hr>
                        <!-- End Looped Elements -->
                            
                        <?php 
                                }
                                $stmt->close();
                            }
                            $conn->close();
                        ?>
                
                    </div>
                    <!-- End Looped Cart List -->

                    <!-- Order Summary -->
                    <div class="col-lg-4 col-md-6">
                        <div class="checkout__order">
                            <h2 class="order__title">Order Summary</h2>
                            <div class="checkout__order__products product-price">
                                Total
                                <span class="product-price"><?php echo $subtotal; ?></span>
                            </div>
        
                            <form method="post" action="checkout.php">  
                                <input class="site-btn" type="submit" name="checkout" value="Check Out">
                            </form>
                        </div>
                    </div>
                </div>

            </div>
            <!-- End of Dynamic Shopping Cart -->
  
        <?php } ?>



        <!-- Empty Cart Button -->
        <form method="post" action="empty_cart.php">
                <input type="submit" name="empty_cart" value="Empty Cart">
        </form>

    </div>
    <?php 
        include "new_includes/footer.inc.php";
    ?>
        </main>
</body>

</html>