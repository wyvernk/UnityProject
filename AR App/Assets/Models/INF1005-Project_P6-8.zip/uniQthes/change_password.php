<?php 
	session_start ();
	if(!isset($_SESSION["login"])) {
        header("location:index.php");
        exit();
    }
  
?>
<!DOCTYPE html>
<html lang="en">

<?php 
    include "new_includes/head.inc.php"
?>

<body>
    <script defer src="js/validation.js"></script>

    <main>
        <?php 
            include "new_includes/nav.inc.php"
        ?>
        <section>
            <div class="container">
                <div class="row d-flex justify-content-center align-items-center h-100">
                    <div class="col-12 col-md-8 col-lg-6 col-xl-5">
                        <div class="card shadow-2-strong" style="border-radius: 1rem;">
                            <div class="card-body p-5 text-center" style="background-color:#fdfdfd;">
                                <h2 class="mb-5">Change Password</h2>

                                <form method="post" action="update_password.php">    
                                    <input type="hidden" value="<?php echo $_SESSION["user_id"]?>">

                                    <span class="errMsg"><?php echo $_SESSION["errorMsg"]; ?></span><br>

                                    <!-- Current Password -->
                                    <div class="form-outline">
                                        <br><label for="currPwd">Current password</label>
                                        <input type="password" class="form-control" id="currPwd" name="currPwd" data-validation-required-message="Please enter your current password" placeholder="Current password" required>
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $_SESSION["currPwdErr"]; ?></span><br>
                                    </div>
                                
                                    <!-- New Password -->
                                    <div class="form-outline">
                                        <br><label for="newPwd">New password</label>
                                        <input type="password" class="form-control" id="newPwd" name="newPwd" data-validation-required-message="Please enter your new password" placeholder="New password" required>
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $_SESSION["pwdErr"]; ?></span><br>
                                    </div>

                                    <!-- Comfirm Password -->
                                    <div class="form-outline">
                                        <br><label for="cfmPwd">Confirm password</label>
                                        <input type="password" class="form-control" id="cfmPwd" name="cfmPwd" data-validation-required-message="Please confirm password" placeholder="Confirm password" required>
                                        <div class="invalid-feedback"></div>
                                        <span class="errMsg"><?php echo $_SESSION["pwdConfirmErr"]; ?></span><br>
                                    </div>

                                    <!-- Change Password Button -->
                                    <button type="submit" class="site-btn btn-lg submit-btn">Change Password</button><br>                       
                                </form>
                                <hr class="my-2">

                                <!-- Cancel Button -->
                                <button onclick="window.location.href='profile.php'" class="cancel-btn">Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php 

            // Reset error messages
            unset(
                $_SESSION["currPwdErr"],
                $_SESSION["errorMsg"],
                $_SESSION["pwdErr"],
                $_SESSION["pwdConfirmErr"]
            );

    ?>

    <?php 
        include "new_includes/footer.inc.php";
    ?>
</body>

</html>